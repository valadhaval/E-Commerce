<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin'])) {
    header("Location:../user/login.php");
    exit();
}

/* ADD CATEGORY - Logic Maintained */
if(isset($_POST['add_category'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $icon = mysqli_real_escape_string($conn, $_POST['icon']);
    $sql = "INSERT INTO categories(name,icon) VALUES('$name','$icon')";
    mysqli_query($conn, $sql);
    header("Location:manage_categories.php");
}

/* DELETE CATEGORY - Logic Maintained */
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete = "DELETE FROM categories WHERE id='$id'";
    mysqli_query($conn, $delete);
    header("Location:manage_categories.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Category Terminal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --admin-accent: #00d2ff;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 0% 100%, rgba(0, 210, 255, 0.08), transparent 50%);
        }

        /* --- NAVBAR --- */
        .navbar {
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
            color: var(--admin-accent) !important;
            font-weight: 700;
        }

        /* --- ADD SECTION --- */
        .input-terminal {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 25px;
            padding: 30px;
            margin-top: 40px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        }

        .form-control {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid var(--border) !important;
            color: white !important;
            border-radius: 12px;
            padding: 12px 15px;
        }

        .form-control:focus {
            border-color: var(--admin-accent) !important;
            box-shadow: 0 0 15px rgba(0, 210, 255, 0.2);
        }

        .btn-add {
            background: var(--admin-accent);
            color: #000;
            font-weight: 700;
            border-radius: 12px;
            border: none;
            transition: 0.3s;
        }

        .btn-add:hover {
            background: #fff;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 210, 255, 0.3);
        }

        /* --- CATEGORY TILES --- */
        .cat-tile {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 22px;
            padding: 30px;
            text-align: center;
            transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .cat-tile:hover {
            background: rgba(0, 210, 255, 0.05);
            border-color: var(--admin-accent);
            transform: translateY(-10px);
        }

        .cat-icon-wrapper {
            width: 70px;
            height: 70px;
            background: rgba(255,255,255,0.02);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 28px;
            color: var(--admin-accent);
            border: 1px solid var(--border);
            transition: 0.3s;
        }

        .cat-tile:hover .cat-icon-wrapper {
            background: var(--admin-accent);
            color: #000;
            box-shadow: 0 0 20px rgba(0, 210, 255, 0.5);
        }

        .cat-name {
            font-weight: 600;
            letter-spacing: 1px;
            margin-bottom: 15px;
        }

        /* --- DELETE BUTTON --- */
        .btn-delete-hex {
            background: rgba(255, 71, 87, 0.1);
            color: #ff4757;
            border: 1px solid rgba(255, 71, 87, 0.2);
            border-radius: 10px;
            padding: 5px 15px;
            font-size: 12px;
            transition: 0.3s;
            text-decoration: none;
        }

        .btn-delete-hex:hover {
            background: #ff4757;
            color: white;
        }

        .helper-text {
            font-size: 11px;
            color: #555;
            margin-top: 5px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand">
            <i class="fa fa-tags me-2"></i> CATEGORY <span class="fw-light">MATRIX</span>
        </a>
        <a href="admin_dashboard.php" class="btn btn-outline-info rounded-pill px-4 btn-sm">
            Dashboard Hub
        </a>
    </div>
</nav>

<div class="container">
    
    <div class="input-terminal">
        <h5 class="mb-4 text-secondary small fw-bold uppercase"><i class="fa fa-plus-circle me-2"></i> Register New Classification</h5>
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-5">
                    <label class="small text-muted mb-2">Display Name</label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Electronics" required>
                </div>
                <div class="col-md-5">
                    <label class="small text-muted mb-2">Icon Glyph (FontAwesome)</label>
                    <input type="text" name="icon" class="form-control" placeholder="e.g. fa-laptop" required>
                    <div class="helper-text">Example: fa-mobile, fa-camera, fa-headset</div>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button class="btn btn-add w-100 py-2" name="add_category">
                        Initialize
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="row mt-5">
        <?php
        $sql = "SELECT * FROM categories ORDER BY id DESC";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
            <div class="cat-tile">
                <div class="cat-icon-wrapper">
                    <i class="fa <?php echo $row['icon']; ?>"></i>
                </div>
                <div class="cat-name"><?php echo $row['name']; ?></div>
                <a href="?delete=<?php echo $row['id']; ?>" 
                   class="btn-delete-hex" 
                   onclick="return confirm('Purge this category from the matrix?')">
                    <i class="fa fa-trash-alt me-1"></i> Erase
                </a>
            </div>
        </div>
        <?php } ?>
    </div>

</div>

<footer class="text-center py-5 opacity-25 small">
    <p>© 2026 NEXGEN DATA // CATEGORY MODULE</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>