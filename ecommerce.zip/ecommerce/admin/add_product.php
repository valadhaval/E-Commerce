<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin'])) {
    header("Location:../user/login.php");
    exit();
}

if(isset($_POST['add_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp, "../images/".$image);

    $sql = "INSERT INTO products(name,price,image,category_id) VALUES('$name','$price','$image','$category')";
    mysqli_query($conn, $sql);
    $success = "Product Synced to Database Successfully";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen Admin | Integration</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --admin-accent: #00d2ff;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 100% 0%, rgba(0, 210, 255, 0.07), transparent 40%);
        }

        /* --- NAVBAR --- */
        .navbar {
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
            color: var(--admin-accent) !important;
            font-weight: 700;
        }

        /* --- INTEGRATION CARD --- */
        .integration-card {
            max-width: 900px;
            margin: 50px auto;
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--border);
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 40px 80px rgba(0,0,0,0.5);
            animation: slideUp 0.6s ease-out;
        }

        .card-header-tech {
            background: rgba(255,255,255,0.02);
            padding: 30px;
            border-bottom: 1px solid var(--border);
            text-align: center;
        }

        .tech-title {
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 3px;
            margin: 0;
            font-size: 1.2rem;
        }

        /* --- FORM STYLING --- */
        .form-body { padding: 40px; }

        label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--admin-accent);
            margin-bottom: 8px;
            font-weight: 600;
        }

        .form-control, .form-select {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid var(--border) !important;
            color: black; !important;
            border-radius: 12px;
            padding: 12px 15px;
            transition: 0.3s;
        }

        .form-control:focus {
            border-color: var(--admin-accent) !important;
            box-shadow: 0 0 15px rgba(0, 210, 255, 0.2);
        }

        /* --- PREVIEW BOX --- */
        #preview-container {
            width: 100%;
            height: 250px;
            border: 2px dashed var(--border);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }

        #preview-img {
            max-width: 100%;
            max-height: 100%;
            display: none;
            object-fit: contain;
        }

        .preview-placeholder {
            text-align: center;
            color: #444;
        }

        /* --- BUTTONS --- */
        .btn-sync {
            background: var(--admin-accent);
            color: #000;
            font-weight: 700;
            text-transform: uppercase;
            border-radius: 12px;
            padding: 15px;
            border: none;
            transition: 0.4s;
            letter-spacing: 1px;
        }

        .btn-sync:hover {
            background: #fff;
            box-shadow: 0 0 25px rgba(0, 210, 255, 0.4);
            transform: translateY(-3px);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand">
            <i class="fa fa-microchip me-2"></i> NEXGEN ADMIN
        </a>
        <a href="admin_dashboard.php" class="btn btn-outline-info btn-sm rounded-pill px-4">
            <i class="fa fa-arrow-left me-2"></i> Dashboard
        </a>
    </div>
</nav>

<div class="container">
    <div class="integration-card">
        <div class="card-header-tech">
            <h4 class="tech-title">Product Integration Shell</h4>
            <p class="text-secondary small mb-0">Input parameters to initialize new inventory unit</p>
        </div>

        <?php if(isset($success)){ ?>
            <div class="mx-5 mt-4 alert alert-info bg-dark text-info border-info small">
                <i class="fa fa-check-circle me-2"></i> <?php echo $success; ?>
            </div>
        <?php } ?>

        <div class="form-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="row g-4">
                    
                    <div class="col-md-5">
                        <label>Asset Visualization</label>
                        <div id="preview-container">
                            <img id="preview-img" src="#" alt="Preview">
                            <div class="preview-placeholder">
                                <i class="fa fa-cloud-upload-alt fa-3x mb-2"></i>
                                <p class="small">Waiting for image...</p>
                            </div>
                        </div>
                        <input type="file" name="image" id="imgInput" class="form-control" required>
                    </div>

                    <div class="col-md-7">
                        <div class="mb-4">
                            <label>Designation (Name)</label>
                            <input type="text" name="name" class="form-control" placeholder="Product Model X" required>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label>Credit Value (Price)</label>
                                <input type="number" name="price" class="form-control" placeholder="0.00" required>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label>Classification (Category)</label>
                                <select name="category" class="form-select" required>
                                    <option value="">Select ID</option>
                                    <?php
                                    $sql="SELECT * FROM categories";
                                    $result=mysqli_query($conn,$sql);
                                    while($row=mysqli_fetch_assoc($result)) {
                                        echo "<option value='".$row['id']."'>".$row['name']."</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="d-grid mt-2">
                            <button class="btn-sync" name="add_product">
                                <i class="fa fa-bolt me-2"></i> Initialize Integration
                            </button>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>

<script>
    imgInput.onchange = evt => {
        const [file] = imgInput.files
        if (file) {
            document.getElementById('preview-img').src = URL.createObjectURL(file);
            document.getElementById('preview-img').style.display = 'block';
            document.querySelector('.preview-placeholder').style.display = 'none';
        }
    }
</script>

</body>
</html>