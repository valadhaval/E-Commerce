<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin']))
{
    header("Location:../user/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Inventory Matrix</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --admin-accent: #00d2ff;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
            --danger: #ff4757;
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 50% 100%, rgba(0, 210, 255, 0.05), transparent 50%);
        }

        /* --- NAVBAR --- */
        .navbar {
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
            color: var(--admin-accent) !important;
            font-weight: 700;
        }

        /* --- INVENTORY CONTAINER --- */
        .matrix-card {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 40px;
            margin-top: 40px;
            box-shadow: 0 40px 100px rgba(0,0,0,0.5);
        }

        .matrix-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            letter-spacing: 2px;
            color: var(--admin-accent);
            margin-bottom: 30px;
        }

        /* --- MODERN TABLE --- */
        .nexgen-table {
            color: white !important;
            border-collapse: separate;
            border-spacing: 0 10px;
        }

        .nexgen-table thead th {
            border: none;
            color: #555;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 1.5px;
            padding: 15px;
        }

        .inventory-row {
            background: rgba(255, 255, 255, 0.02);
            transition: 0.3s;
        }

        .inventory-row:hover {
            background: rgba(0, 210, 255, 0.05);
            transform: scale(1.005);
        }

        .inventory-row td {
            padding: 15px !important;
            vertical-align: middle;
            border-top: 1px solid var(--border) !important;
            border-bottom: 1px solid var(--border) !important;
        }

        .inventory-row td:first-child { border-left: 1px solid var(--border); border-radius: 15px 0 0 15px; }
        .inventory-row td:last-child { border-right: 1px solid var(--border); border-radius: 0 15px 15px 0; }

        /* --- PRODUCT STYLING --- */
        .product-thumb {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid var(--border);
            padding: 3px;
            background: #111;
        }

        .category-badge {
            font-size: 10px;
            background: rgba(255, 255, 255, 0.05);
            padding: 5px 12px;
            border-radius: 50px;
            border: 1px solid var(--border);
            color: #aaa;
        }

        .price-tag {
            color: var(--admin-accent);
            font-weight: 700;
        }

        /* --- ACTION BUTTONS --- */
        .btn-action {
            width: 35px;
            height: 35px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            text-decoration: none;
            transition: 0.3s;
            border: 1px solid transparent;
        }

        .btn-edit {
            background: rgba(0, 210, 255, 0.1);
            color: var(--admin-accent);
        }

        .btn-edit:hover {
            background: var(--admin-accent);
            color: black;
            box-shadow: 0 0 15px rgba(0, 210, 255, 0.4);
        }

        .btn-delete {
            background: rgba(255, 71, 87, 0.1);
            color: var(--danger);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: white;
            box-shadow: 0 0 15px rgba(255, 71, 87, 0.4);
        }

    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand">
            <i class="fa fa-layer-group me-2"></i> INVENTORY <span class="fw-light">CONTROL</span>
        </a>
        <div class="d-flex gap-2">
            <a href="add_product.php" class="btn btn-outline-info rounded-pill px-4 btn-sm">
                <i class="fa fa-plus me-1"></i> New Entry
            </a>
            <a href="admin_dashboard.php" class="btn btn-dark rounded-pill px-4 btn-sm border-secondary">
                Dashboard
            </a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="matrix-card">
        <h4 class="matrix-title">System Assets</h4>

        <div class="table-responsive">
            <table class="table nexgen-table">
                <thead>
                    <tr>
                        <th>UID</th>
                        <th>Visual</th>
                        <th>Designation</th>
                        <th>Credit Value</th>
                        <th>Classification</th>
                        <th class="text-center">Operations</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                $sql="SELECT products.*, categories.name AS category_name
                FROM products
                LEFT JOIN categories
                ON products.category_id=categories.id
                ORDER BY products.id DESC";

                $result=mysqli_query($conn,$sql);

                while($row=mysqli_fetch_assoc($result))
                {
                ?>

                <tr class="inventory-row">
                    <td class="text-secondary small">#<?php echo $row['id']; ?></td>
                    <td>
                        <img src="../images/<?php echo $row['image']; ?>" class="product-thumb">
                    </td>
                    <td class="fw-bold"><?php echo $row['name']; ?></td>
                    <td class="price-tag">₹<?php echo number_format($row['price'], 2); ?></td>
                    <td>
                        <span class="category-badge">
                            <?php echo $row['category_name'] ? $row['category_name'] : 'Unclassified'; ?>
                        </span>
                    </td>
                    <td class="text-center">
                        <div class="d-flex justify-content-center gap-2">
                            <a href="edit_product.php?id=<?php echo $row['id']; ?>" class="btn-action btn-edit">
                                <i class="fa fa-pen-nib"></i>
                            </a>
                            <a href="delete_product.php?id=<?php echo $row['id']; ?>" 
                               class="btn-action btn-delete" 
                               onclick="return confirm('Initiate product deletion sequence?')">
                                <i class="fa fa-trash-alt"></i>
                            </a>
                        </div>
                    </td>
                </tr>

                <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="text-center py-5 opacity-25 small">
    <p>© 2026 NEXGEN LOGISTICS // DATA TERMINAL</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>