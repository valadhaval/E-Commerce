<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin']))
{
header("Location:../user/login.php");
exit();
}

$id=$_GET['id'];

$sql="SELECT * FROM products WHERE id='$id'";
$result=mysqli_query($conn,$sql);
$product=mysqli_fetch_assoc($result);

if(isset($_POST['update_product']))
{

$name=$_POST['name'];
$price=$_POST['price'];
$category=$_POST['category'];

$image=$_FILES['image']['name'];

if($image!="")
{
$tmp=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp,"../images/".$image);

$update="UPDATE products 
SET name='$name', price='$price', image='$image', category_id='$category'
WHERE id='$id'";
}
else
{

$update="UPDATE products 
SET name='$name', price='$price', category_id='$category'
WHERE id='$id'";

}

mysqli_query($conn,$update);

header("Location:manage_products.php");

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Product</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{
background:#f4f6fb;
font-family:Segoe UI;
}

/* NAVBAR */

.navbar{
background:#111;
}

/* FORM CARD */

.form-card{

width:500px;
margin:auto;
margin-top:50px;

background:white;

padding:40px;

border-radius:20px;

box-shadow:0 20px 40px rgba(0,0,0,0.2);

transition:0.4s;

}

.form-card:hover{
transform:translateY(-8px);
}

.title{
text-align:center;
margin-bottom:30px;
font-weight:bold;
}

.product-img{
width:100px;
border-radius:10px;
margin-bottom:10px;
}

</style>

</head>

<body>

<nav class="navbar navbar-dark">

<div class="container">

<a class="navbar-brand">
<i class="fa fa-edit"></i> Edit Product
</a>

<a href="manage_products.php" class="btn btn-warning">
Back
</a>

</div>

</nav>

<div class="form-card">

<h4 class="title">Edit Product</h4>

<form method="POST" enctype="multipart/form-data">

<div class="mb-3">

<label>Product Name</label>

<input type="text"
name="name"
class="form-control"
value="<?php echo $product['name']; ?>"
required>

</div>

<div class="mb-3">

<label>Price</label>

<input type="number"
name="price"
class="form-control"
value="<?php echo $product['price']; ?>"
required>

</div>

<div class="mb-3">

<label>Category</label>

<select name="category" class="form-control">

<?php

$cat="SELECT * FROM categories";
$cat_result=mysqli_query($conn,$cat);

while($c=mysqli_fetch_assoc($cat_result))
{

$selected="";

if($product['category_id']==$c['id'])
{
$selected="selected";
}

?>

<option value="<?php echo $c['id']; ?>" <?php echo $selected; ?>>
<?php echo $c['name']; ?>
</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Current Image</label><br>

<img src="../images/<?php echo $product['image']; ?>" class="product-img">

</div>

<div class="mb-3">

<label>Change Image</label>

<input type="file"
name="image"
class="form-control">

</div>

<div class="d-grid">

<button class="btn btn-warning"
name="update_product">

<i class="fa fa-save"></i> Update Product

</button>

</div>

</form>

</div>

</body>

</html>