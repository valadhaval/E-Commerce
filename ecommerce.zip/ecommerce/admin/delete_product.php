<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin']))
{
header("Location:../user/login.php");
exit();
}

if(isset($_GET['id']))
{

$id=$_GET['id'];

$sql="SELECT * FROM products WHERE id='$id'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);

$image=$row['image'];

/* DELETE IMAGE */

if(file_exists("../images/".$image))
{
unlink("../images/".$image);
}

/* DELETE PRODUCT */

$delete="DELETE FROM products WHERE id='$id'";
mysqli_query($conn,$delete);

header("Location:manage_products.php");

}
?>