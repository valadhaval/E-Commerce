<?php
session_start();

if(!isset($_SESSION['admin'])) {
    header("Location:../user/login.php");
    exit();
}

include "../config/db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Admin Terminal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --admin-accent: #00d2ff; /* Tech Blue for Admin */
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 0% 0%, rgba(0, 210, 255, 0.05), transparent 40%);
        }

        /* --- SIDEBAR NAV --- */
        .admin-sidebar {
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(20px);
            border-right: 1px solid var(--border);
            height: 100vh;
            position: fixed;
            width: 260px;
            padding: 30px 20px;
        }

        .admin-brand {
            font-family: 'Orbitron', sans-serif;
            font-size: 22px;
            color: var(--admin-accent);
            text-align: center;
            margin-bottom: 50px;
            letter-spacing: 2px;
        }

        .nav-link-custom {
            color: #888;
            padding: 12px 20px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            transition: 0.3s;
            margin-bottom: 10px;
        }

        .nav-link-custom:hover, .nav-link-custom.active {
            background: var(--glass);
            color: var(--admin-accent);
            border: 1px solid var(--border);
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            margin-left: 260px;
            padding: 40px;
        }

        /* --- METRIC CARDS --- */
        .metric-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .metric-card {
            background: var(--glass);
            border: 1px solid var(--border);
            padding: 20px;
            border-radius: 20px;
            text-align: left;
        }

        .metric-value {
            font-size: 24px;
            font-weight: 700;
            display: block;
            color: white;
        }

        .metric-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
        }

        /* --- ACTION BOXES --- */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }

        .admin-box {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 25px;
            padding: 35px;
            text-align: center;
            transition: 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-decoration: none;
            display: block;
            color: white;
        }

        .admin-box::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(45deg, transparent, rgba(0, 210, 255, 0.05), transparent);
            transform: translateX(-100%);
            transition: 0.6s;
        }

        .admin-box:hover::before { transform: translateX(100%); }

        .admin-box:hover {
            transform: translateY(-10px);
            border-color: var(--admin-accent);
            box-shadow: 0 20px 40px rgba(0, 210, 255, 0.1);
        }

        .box-icon {
            font-size: 45px;
            color: var(--admin-accent);
            margin-bottom: 20px;
            filter: drop-shadow(0 0 10px rgba(0, 210, 255, 0.3));
        }

        .logout-btn {
            background: #ff4757;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            width: 100%;
            margin-top: 50px;
            font-weight: bold;
        }

        @media (max-width: 992px) {
            .admin-sidebar { width: 80px; padding: 20px 10px; }
            .admin-brand, .link-text, .logout-btn span { display: none; }
            .main-content { margin-left: 80px; }
        }
    </style>
</head>
<body>

    <div class="admin-sidebar">
        <div class="admin-brand">NEXGEN</div>
        
        <a href="admin_dashboard.php" class="nav-link-custom active">
            <i class="fa fa-th-large"></i> <span class="link-text">Terminal</span>
        </a>
        <a href="manage_products.php" class="nav-link-custom">
            <i class="fa fa-box"></i> <span class="link-text">Inventory</span>
        </a>
        <a href="orders.php" class="nav-link-custom">
            <i class="fa fa-shopping-cart"></i> <span class="link-text">Orders</span>
        </a>
        <a href="sales.php" class="nav-link-custom">
            <i class="fa fa-chart-line"></i> <span class="link-text">Analytics</span>
        </a>

        <a href="../user/logout.php" class="logout-btn nav-link-custom text-center justify-content-center mt-5">
            <i class="fa fa-sign-out-alt"></i> <span class="link-text">System Exit</span>
        </a>
    </div>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h2 class="fw-bold mb-0">System Dashboard</h2>
                <p class="text-secondary small">OPERATOR: <?php echo strtoupper($_SESSION['admin']); ?> // STATUS: ENCRYPTED</p>
            </div>
            <div class="text-end">
                <span class="badge bg-dark border border-secondary p-2 px-3"><?php echo date('D, d M Y'); ?></span>
            </div>
        </div>

        <div class="metric-row">
            <div class="metric-card">
                <span class="metric-label">Daily Revenue</span>
                <span class="metric-value">₹ 84,250</span>
            </div>
            <div class="metric-card">
                <span class="metric-label">New Orders</span>
                <span class="metric-value">12</span>
            </div>
            <div class="metric-card">
                <span class="metric-label">Active Users</span>
                <span class="metric-value">142</span>
            </div>
        </div>

        <div class="dashboard-grid">
            <a href="add_product.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-plus-square"></i></div>
                <h5>Add Product</h5>
                <p class="text-secondary small">Integrate new items into catalog</p>
            </a>

            <a href="manage_products.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-layer-group"></i></div>
                <h5>Inventory</h5>
                <p class="text-secondary small">Modify or remove stock items</p>
            </a>

            <a href="manage_categories.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-tags"></i></div>
                <h5>Categories</h5>
                <p class="text-secondary small">Organize department structure</p>
            </a>

            <a href="orders.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-receipt"></i></div>
                <h5>Order Vault</h5>
                <p class="text-secondary small">Process customer transactions</p>
            </a>

            <a href="users.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-user-gear"></i></div>
                <h5>User Control</h5>
                <p class="text-secondary small">Manage registered memberships</p>
            </a>

            <a href="sales.php" class="admin-box">
                <div class="box-icon"><i class="fa fa-chart-pie"></i></div>
                <h5>Analytics</h5>
                <p class="text-secondary small">Deep dive into sales data</p>
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>