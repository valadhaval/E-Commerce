<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin']))
{
header("Location:../user/login.php");
exit();
}

/* TOTAL PRODUCTS */

$product_sql="SELECT COUNT(*) AS total_products FROM products";
$product_result=mysqli_query($conn,$product_sql);
$product_data=mysqli_fetch_assoc($product_result);

/* TOTAL ORDERS */

$order_sql="SELECT COUNT(*) AS total_orders FROM orders";
$order_result=mysqli_query($conn,$order_sql);
$order_data=mysqli_fetch_assoc($order_result);

/* TOTAL USERS */

$user_sql="SELECT COUNT(*) AS total_users FROM users";
$user_result=mysqli_query($conn,$user_sql);
$user_data=mysqli_fetch_assoc($user_result);

/* TOTAL SALES */

$sales_sql="SELECT SUM(total) AS total_sales FROM orders";
$sales_result=mysqli_query($conn,$sales_sql);
$sales_data=mysqli_fetch_assoc($sales_result);

$total_sales = $sales_data['total_sales'] ?? 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Sales Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

body{
background:#f4f6fb;
font-family:Segoe UI;
}

/* NAVBAR */

.navbar{
background:#111;
}

/* DASHBOARD CARD */

.stat-card{

background:white;

padding:30px;

border-radius:20px;

text-align:center;

box-shadow:0 20px 40px rgba(0,0,0,0.15);

transition:0.4s;

}

.stat-card:hover{

transform:translateY(-8px) scale(1.03);

}

/* ICON */

.stat-icon{

font-size:40px;

margin-bottom:15px;

color:#ffc107;

}

/* NUMBER */

.stat-number{

font-size:28px;

font-weight:bold;

}

</style>

</head>

<body>

<nav class="navbar navbar-dark">

<div class="container">

<a class="navbar-brand">
<i class="fa fa-chart-line"></i> Sales Dashboard
</a>

<a href="admin_dashboard.php" class="btn btn-warning">
Dashboard
</a>

</div>

</nav>

<div class="container mt-5">

<div class="row">

<!-- TOTAL PRODUCTS -->

<div class="col-md-3 mb-4">

<div class="stat-card">

<div class="stat-icon">
<i class="fa fa-box"></i>
</div>

<h6>Total Products</h6>

<div class="stat-number">
<?php echo $product_data['total_products']; ?>
</div>

</div>

</div>

<!-- TOTAL ORDERS -->

<div class="col-md-3 mb-4">

<div class="stat-card">

<div class="stat-icon">
<i class="fa fa-shopping-cart"></i>
</div>

<h6>Total Orders</h6>

<div class="stat-number">
<?php echo $order_data['total_orders']; ?>
</div>

</div>

</div>

<!-- TOTAL USERS -->

<div class="col-md-3 mb-4">

<div class="stat-card">

<div class="stat-icon">
<i class="fa fa-users"></i>
</div>

<h6>Total Users</h6>

<div class="stat-number">
<?php echo $user_data['total_users']; ?>
</div>

</div>

</div>

<!-- TOTAL SALES -->

<div class="col-md-3 mb-4">

<div class="stat-card">

<div class="stat-icon">
<i class="fa fa-indian-rupee-sign"></i>
</div>

<h6>Total Sales</h6>

<div class="stat-number">
₹<?php echo $total_sales; ?>
</div>

</div>

</div>

</div>

</div>

</body>

</html>