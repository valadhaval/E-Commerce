<?php
session_start();
include "../config/db.php";

if(!isset($_SESSION['admin'])) {
    header("Location:../user/login.php");
    exit();
}

/* DELETE USER LOGIC */
if(isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    $delete = "DELETE FROM users WHERE id='$id'";
    mysqli_query($conn, $delete);
    header("Location:users.php?msg=User Purged");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Identity Control</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --admin-accent: #00d2ff;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
            --danger: #ff4757;
            --success: #00ff9d;
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 0% 0%, rgba(0, 210, 255, 0.05), transparent 40%);
        }

        .navbar {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }

        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
            color: var(--admin-accent) !important;
            font-weight: 700;
        }

        .user-matrix {
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 40px;
            margin-top: 40px;
            box-shadow: 0 40px 100px rgba(0,0,0,0.6);
        }

        .matrix-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 20px;
        }

        .matrix-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.3rem;
            color: var(--admin-accent);
            letter-spacing: 2px;
        }

        .nexgen-table { color: #ddd !important; vertical-align: middle; }
        .nexgen-table thead th { color: #666; font-size: 11px; text-transform: uppercase; border: none; padding: 15px; }

        .user-row { border-bottom: 1px solid rgba(255,255,255,0.03); transition: 0.3s; }
        .user-row:hover { background: rgba(255, 255, 255, 0.02); }

        .user-avatar {
            width: 40px; height: 40px;
            background: linear-gradient(45deg, var(--admin-accent), #004e92);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; color: #000; font-size: 14px; margin-right: 15px;
        }

        .status-dot {
            width: 8px; height: 8px; background: var(--success);
            border-radius: 50%; display: inline-block; margin-right: 8px;
            box-shadow: 0 0 10px var(--success);
        }

        .btn-terminate {
            background: rgba(255, 71, 87, 0.1);
            color: var(--danger);
            border: 1px solid rgba(255, 71, 87, 0.2);
            width: 38px; height: 38px; border-radius: 10px;
            display: inline-flex; align-items: center; justify-content: center;
            transition: 0.3s;
        }

        .btn-terminate:hover {
            background: var(--danger); color: white;
            box-shadow: 0 0 15px rgba(255, 71, 87, 0.4);
            transform: rotate(90deg);
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand">
            <i class="fa fa-user-shield me-2"></i> IDENTITY <span class="fw-light">CONTROL</span>
        </a>
        <a href="admin_dashboard.php" class="btn btn-outline-info rounded-pill px-4 btn-sm">
            <i class="fa fa-arrow-left me-2"></i> Dashboard
        </a>
    </div>
</nav>

<div class="container mb-5">
    <div class="user-matrix">
        <div class="matrix-header">
            <h4 class="matrix-title">Registered Personnel</h4>
            <span class="badge bg-dark border border-secondary text-secondary px-3 py-2">SECURE DIRECTORY</span>
        </div>

        <div class="table-responsive">
            <table class="table nexgen-table">
                <thead>
                    <tr>
                        <th>UID</th>
                        <th>User Profile</th>
                        <th>Contact Signal</th>
                        <th>Status</th>
                        <th class="text-center">Protocol</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                $sql = "SELECT * FROM users ORDER BY id DESC";
                $result = mysqli_query($conn, $sql);

                while($row = mysqli_fetch_assoc($result)) {
                    // FIXED INITIALS LOGIC
                    $name = trim($row['name']); // Remove leading/trailing spaces
                    $initials = "U"; // Default initial if name is empty
                    
                    if(!empty($name)) {
                        $words = explode(" ", $name);
                        $initials = "";
                        foreach ($words as $w) {
                            if(!empty($w)) {
                                $initials .= $w[0];
                            }
                        }
                        $initials = strtoupper(substr($initials, 0, 2));
                    }
                ?>
                <tr class="user-row">
                    <td class="text-secondary small">#<?php echo $row['id']; ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="user-avatar"><?php echo $initials; ?></div>
                            <div class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></div>
                        </div>
                    </td>
                    <td class="text-info"><?php echo htmlspecialchars($row['email']); ?></td>
                    <td>
                        <span class="small text-secondary">
                            <span class="status-dot"></span> Authorized
                        </span>
                    </td>
                    <td class="text-center">
                        <a href="?delete=<?php echo $row['id']; ?>" 
                           class="btn-terminate" 
                           onclick="return confirm('Purge User Identity?')">
                            <i class="fa fa-user-xmark"></i>
                        </a>
                    </td>
                </tr>
                <?php } ?>

                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="text-center py-4 opacity-25 small">
    <p>© 2026 NEXGEN SECURITY // AUTH MODULE</p>
</footer>

</body>
</html>