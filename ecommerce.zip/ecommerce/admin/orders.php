<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['admin'])) {
    header("Location:../user/login.php");
    exit();
}

/* ====================== ACTION HANDLING ====================== */

// Delete Order
if (isset($_GET['delete_order'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_order']);
    $sql = "DELETE FROM orders WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        header("Location:orders.php?msg=Order Deleted Successfully");
        exit();
    }
}

// Accept / Mark as Processing
if (isset($_GET['accept_order'])) {
    $id = mysqli_real_escape_string($conn, $_GET['accept_order']);
    $sql = "UPDATE orders SET status = 'Processing' WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        header("Location:orders.php?msg=Order Accepted & Moved to Processing");
        exit();
    }
}

// Optional: Mark as Shipped (you can extend later)
if (isset($_GET['ship_order'])) {
    $id = mysqli_real_escape_string($conn, $_GET['ship_order']);
    $sql = "UPDATE orders SET status = 'Shipped' WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        header("Location:orders.php?msg=Order Marked as Shipped");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Transaction Log</title>
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --admin-accent: #00d2ff;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
            --success: #00ff9d;
            --danger: #ff4757;
        }
        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 100% 100%, rgba(0, 210, 255, 0.05), transparent 40%);
        }
        .navbar {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }
        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
            color: var(--admin-accent) !important;
            font-weight: 700;
        }
        .log-card {
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 40px;
            margin-top: 40px;
            box-shadow: 0 40px 80px rgba(0,0,0,0.6);
        }
        .log-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.4rem;
            letter-spacing: 2px;
            color: var(--admin-accent);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .nexgen-table {
            color: #eee !important;
            vertical-align: middle;
        }
        .nexgen-table thead th {
            background: rgba(255,255,255,0.02);
            border-bottom: 1px solid var(--border);
            color: #666;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px;
        }
        .nexgen-table tbody tr {
            border-bottom: 1px solid rgba(255,255,255,0.03);
            transition: 0.3s;
        }
        .nexgen-table tbody tr:hover {
            background: rgba(255, 255, 255, 0.02);
        }
        .pay-badge {
            background: rgba(0, 255, 157, 0.1);
            color: var(--success);
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            border: 1px solid rgba(0, 255, 157, 0.2);
        }
        .status-pending   { background: rgba(255, 193, 7, 0.15); color: #ffc107; border: 1px solid rgba(255,193,7,0.3); }
        .status-processing{ background: rgba(0, 210, 255, 0.15); color: #00d2ff; border: 1px solid rgba(0,210,255,0.3); }
        .status-shipped   { background: rgba(0, 255, 157, 0.15); color: #00ff9d; border: 1px solid rgba(0,255,157,0.3); }

        .date-text {
            font-size: 12px;
            color: #888;
            font-family: monospace;
        }
        .price-text {
            font-weight: 700;
            color: var(--admin-accent);
        }
        .btn-purge {
            color: #444;
            transition: 0.3s;
            background: transparent;
            border: none;
            font-size: 18px;
        }
        .btn-purge:hover {
            color: var(--danger);
            transform: scale(1.2);
        }
        .btn-accept {
            background: #00d2ff;
            color: #000;
            font-weight: 600;
            padding: 6px 14px;
            border-radius: 8px;
            font-size: 13px;
            transition: 0.3s;
        }
        .btn-accept:hover {
            background: #fff;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand">
            <i class="fa fa-terminal me-2"></i> TRANSACTION <span class="fw-light">VAULT</span>
        </a>
        <a href="admin_dashboard.php" class="btn btn-outline-info rounded-pill px-4 btn-sm">
            <i class="fa fa-arrow-left me-2"></i> Dashboard
        </a>
    </div>
</nav>

<div class="container mb-5">
    <div class="log-card">
        <h4 class="log-title">
            <i class="fa fa-receipt"></i> Global Order Registry
        </h4>

        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($_GET['msg']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table nexgen-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Product</th>
                        <th>Unit Price</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Timestamp</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT * FROM orders ORDER BY id DESC";
                $result = mysqli_query($conn, $sql);
                while($row = mysqli_fetch_assoc($result)) {
                    $status_class = '';
                    $status_text = $row['status'] ?? 'Pending';

                    if ($status_text == 'Pending') $status_class = 'status-pending';
                    elseif ($status_text == 'Processing') $status_class = 'status-processing';
                    elseif ($status_text == 'Shipped') $status_class = 'status-shipped';
                ?>
                <tr>
                    <td class="text-secondary small">#<?php echo $row['id']; ?></td>
                    <td>
                        <div class="small fw-bold"><?php echo htmlspecialchars($row['user_email']); ?></div>
                        <?php if (!empty($row['name'])): ?>
                            <small class="text-muted"><?php echo htmlspecialchars($row['name']); ?></small>
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                    <td class="price-text">₹<?php echo number_format($row['product_price'], 0); ?></td>
                    <td class="fw-bold">₹<?php echo number_format($row['total'], 0); ?></td>
                    <td>
                        <span class="pay-badge"><?php echo htmlspecialchars($row['payment_method']); ?></span>
                    </td>
                    <td>
                        <span class="pay-badge <?php echo $status_class; ?>">
                            <?php echo $status_text; ?>
                        </span>
                    </td>
                    <td class="date-text">
                        <?php echo date('d M Y | H:i', strtotime($row['order_date'])); ?>
                    </td>
                    <td class="text-center">
                        <?php if (($row['status'] ?? 'Pending') === 'Pending'): ?>
                            <a href="?accept_order=<?php echo $row['id']; ?>" 
                               class="btn btn-accept me-2"
                               onclick="return confirm('Accept this order and mark as Processing?')">
                                <i class="fa fa-check"></i> Accept
                            </a>
                        <?php endif; ?>

                        <a href="?delete_order=<?php echo $row['id']; ?>"
                           class="btn-purge"
                           onclick="return confirm('WARNING: Permanently delete this order?')">
                            <i class="fa fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="text-center py-4 opacity-25 small">
    <p>© 2026 NEXGEN LOGISTICS // SECURE ARCHIVE</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>