<?php
include "config/db.php";
$q = "";
if(isset($_GET['q'])) {
    $q = mysqli_real_escape_string($conn, $_GET['q']);
}
$sql = "SELECT * FROM products WHERE name LIKE '%$q%'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search | NexGen Premium Store</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --glass: rgba(255, 255, 255, 0.05);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background: #0a0a0a;
            color: #fff;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* --- SEARCH HEADER AREA --- */
        .search-hero {
            background: linear-gradient(to bottom, #111, #0a0a0a);
            padding: 100px 0 60px;
            border-bottom: 1px solid var(--border);
            text-align: center;
        }

        .search-title {
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        /* --- ADVANCED SEARCH BAR --- */
        .search-wrapper {
            max-width: 600px;
            margin: 0 auto;
            position: relative;
        }

        .search-input {
            background: var(--glass) !important;
            border: 1px solid var(--border) !important;
            color: white !important;
            padding: 15px 30px;
            border-radius: 50px !important;
            backdrop-filter: blur(10px);
            transition: 0.4s;
        }

        .search-input:focus {
            box-shadow: 0 0 20px rgba(255, 193, 7, 0.2);
            border-color: var(--accent) !important;
        }

        .search-btn {
            background: var(--accent);
            border: none;
            border-radius: 50px !important;
            padding: 0 25px;
            font-weight: bold;
            transition: 0.3s;
        }

        .search-btn:hover {
            transform: scale(1.05);
            background: #e5ac00;
        }

        /* --- 3D PRODUCT CARDS --- */
        .grid-container {
            perspective: 1200px;
            padding-top: 50px;
        }

        .product-card {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 20px;
            transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
            transform-style: preserve-3d;
            height: 100%;
            position: relative;
        }

        .product-card:hover {
            transform: rotateY(-10deg) rotateX(5deg) translateY(-10px);
            border-color: var(--accent);
            box-shadow: 20px 20px 60px rgba(0,0,0,0.5);
        }

        .img-container {
            height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
            transform: translateZ(40px); /* Popping effect */
        }

        .product-img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            filter: drop-shadow(0 10px 15px rgba(0,0,0,0.3));
        }

        .product-info {
            margin-top: 25px;
            transform: translateZ(25px);
            text-align: center;
        }

        .price-tag {
            color: var(--accent);
            font-size: 1.5rem;
            font-weight: 700;
        }

        /* --- CART BUTTON --- */
        .btn-action {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: #fff;
            border-radius: 12px;
            padding: 10px;
            transition: 0.3s;
            width: 100%;
        }

        .btn-action:hover {
            background: var(--accent);
            color: #000;
            font-weight: bold;
        }

        /* --- EMPTY STATE --- */
        .empty-state {
            padding: 100px 0;
            text-align: center;
            opacity: 0.5;
        }

        .empty-state i { font-size: 5rem; margin-bottom: 20px; }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #0a0a0a; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: var(--accent); }

    </style>
</head>
<body>

<nav class="navbar navbar-dark py-3">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php" style="color: var(--accent);">
            <i class="fa fa-arrow-left me-2"></i> BACK TO STORE
        </a>
    </div>
</nav>

<section class="search-hero">
    <div class="container">
        <h2 class="search-title">Discover <span style="color:var(--accent)">Innovation</span></h2>
        
        <div class="search-wrapper">
            <form method="GET" action="search.php">
                <div class="input-group">
                    <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" 
                           class="form-control search-input" placeholder="What are you looking for?">
                    <button class="btn search-btn" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </form>
        </div>
        
        <?php if($q != ""): ?>
            <p class="mt-4 text-secondary">Showing results for: <b class="text-white">"<?php echo $q; ?>"</b></p>
        <?php endif; ?>
    </div>
</section>

<div class="container grid-container">
    <div class="row">

    <?php
    if(mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
    ?>

    <div class="col-xl-3 col-lg-4 col-md-6 mb-5">
        <div class="product-card">
            
            <div class="img-container">
                <img src="images/<?php echo $row['image']; ?>" class="product-img" alt="Product">
            </div>

            <div class="product-info">
                <h5 class="fw-bold"><?php echo $row['name']; ?></h5>
                <p class="price-tag">₹<?php echo number_format($row['price'], 2); ?></p>
                
                <div class="mt-3">
                    <a href="#?id=<?php echo $row['id']; ?>" class="btn btn-action">
                        <i class="fa fa-shopping-basket me-2"></i>Add to Cart
                    </a>
                </div>
            </div>

        </div>
    </div>

    <?php 
        } 
    } else { 
    ?>

    <div class="col-12">
        <div class="empty-state">
            <i class="fa fa-ghost"></i>
            <h3>No Products Found</h3>
            <p>Try searching for something else, like "Gadgets" or "Watch".</p>
            <a href="search.php" class="btn btn-outline-warning mt-3 px-4">Clear Search</a>
        </div>
    </div>

    <?php } ?>

    </div>
</div>

<footer class="py-5 mt-5 text-center text-secondary border-top border-secondary" style="opacity: 0.3;">
    <p>© 2026 NEXGEN | High Performance E-Commerce</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>