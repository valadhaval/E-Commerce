<?php
session_start();
include "../config/db.php";

if(isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);
    $type = $_POST['type'];

    if($type == "user") {
        $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0) {
            $_SESSION['user'] = $email;
            header("Location:user_dashboard.php");
            exit();
        } else {
            $error = "Access Denied: Invalid User Credentials";
        }
    }

    if($type == "admin") {
        $sql = "SELECT * FROM admins WHERE email='$email' AND password='$password'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0) {
            $_SESSION['admin'] = $email;
            header("Location:../admin/admin_dashboard.php");
            exit();
        } else {
            $error = "Access Denied: Invalid Admin Credentials";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Secure Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.05);
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: var(--bg-dark);
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(255, 193, 7, 0.05) 0%, transparent 20%),
                radial-gradient(circle at 90% 80%, rgba(255, 193, 7, 0.05) 0%, transparent 20%);
            font-family: 'Poppins', sans-serif;
            color: white;
            overflow: hidden;
        }

        .login-container {
            position: relative;
            width: 400px;
            perspective: 1000px;
        }

        .login-card {
            background: var(--glass);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            padding: 50px 40px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.5);
            transition: transform 0.6s cubic-bezier(0.23, 1, 0.32, 1);
            transform-style: preserve-3d;
            position: relative;
        }

        .login-card:hover {
            transform: rotateX(5deg) rotateY(-5deg);
            border-color: var(--accent);
        }

        /* --- BACK BUTTON STYLE --- */
        .back-home {
            position: absolute;
            top: 25px;
            left: 25px;
            color: rgba(255,255,255,0.5);
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 10;
            transform: translateZ(20px);
        }

        .back-home:hover {
            color: var(--accent);
            transform: translateZ(40px) translateX(-5px);
        }

        .icon-sphere {
            width: 80px;
            height: 80px;
            background: var(--accent);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 35px;
            color: #000;
            box-shadow: 0 10px 25px rgba(255, 193, 7, 0.4);
            transform: translateZ(50px);
        }

        .login-title {
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            text-align: center;
            margin-bottom: 35px;
            transform: translateZ(30px);
        }

        .input-group-custom {
            margin-bottom: 20px;
            transform: translateZ(20px);
        }

        .form-control {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid rgba(255,255,255,0.1) !important;
            border-radius: 15px !important;
            color: white !important;
            padding: 12px 20px;
            transition: 0.3s;
        }

        .form-control:focus {
            background: rgba(255,255,255,0.1) !important;
            border-color: var(--accent) !important;
            box-shadow: 0 0 15px rgba(255, 193, 7, 0.2);
        }

        select.form-control option {
            background: #1a1a1a;
            color: white;
        }

        .btn-login {
            background: var(--accent);
            color: #000;
            font-weight: 700;
            border-radius: 15px;
            padding: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border: none;
            transition: 0.4s;
            transform: translateZ(40px);
        }

        .btn-login:hover {
            background: #fff;
            transform: translateZ(60px) scale(1.05);
            box-shadow: 0 15px 30px rgba(0,0,0,0.4);
        }

        .error-msg {
            background: rgba(255, 107, 107, 0.1);
            color: #ff6b6b;
            padding: 10px;
            border-radius: 10px;
            border: 1px solid rgba(255, 107, 107, 0.2);
            font-size: 13px;
            text-align: center;
            margin-bottom: 20px;
        }

        .register-link {
            text-decoration: none;
            color: var(--accent);
            font-weight: 600;
            transition: 0.3s;
        }

        .register-link:hover {
            color: #fff;
            text-shadow: 0 0 10px var(--accent);
        }

    </style>
</head>
<body>

<div class="login-container">
    <div class="login-card">
        
        <a href="../index.php" class="back-home">
            <i class="fa fa-arrow-left"></i> Home
        </a>
        
        <div class="icon-sphere">
            <i class="fa fa-shield-halved"></i>
        </div>

        <h3 class="login-title">Secure Login</h3>

        <?php if(isset($error)): ?>
            <div class="error-msg">
                <i class="fa fa-exclamation-circle me-1"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group-custom">
                <label class="small text-secondary mb-2 ms-2">Account Type</label>
                <select name="type" class="form-control" required>
                    <option value="user">Standard User</option>
                    <option value="admin">System Administrator</option>
                </select>
            </div>

            <div class="input-group-custom">
                <input type="email" name="email" class="form-control" placeholder="Email Address" required>
            </div>

            <div class="input-group-custom">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <div class="d-grid mt-4">
                <button type="submit" name="login" class="btn btn-login">
                    Authorize Access <i class="fa fa-key ms-2"></i>
                </button>
            </div>
        </form>

        <div class="text-center mt-4 pt-2">
            <p class="small text-secondary mb-0">New to NexGen?</p>
            <a href="register.php" class="register-link">Create an Account</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>