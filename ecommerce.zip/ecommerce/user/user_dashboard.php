<?php
session_start();

if(!isset($_SESSION['user'])) {
    header("Location:login.php");
    exit();
}

include "../config/db.php";

$category = "";
if(isset($_GET['category'])) {
    $category = mysqli_real_escape_string($conn, $_GET['category']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | My Dashboard</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --dark-surface: #0f1116;
            --glass: rgba(255, 255, 255, 0.05);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: #050505;
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }

        /* --- NAVIGATION --- */
        .dashboard-nav {
            background: rgba(10, 10, 10, 0.8) !important;
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
            padding: 15px 0;
        }

        /* --- USER WELCOME CARD --- */
        .welcome-banner {
            background: linear-gradient(135deg, #1a1a1a 0%, #000 100%);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 40px;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0,0,0,0.5);
        }

        .welcome-banner::after {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: var(--accent);
            filter: blur(120px);
            opacity: 0.1;
        }

        /* --- 3D CATEGORY CHIPS --- */
        .category-scroll {
            display: flex;
            gap: 15px;
            overflow-x: auto;
            padding: 10px 5px 25px;
            scrollbar-width: none; /* Firefox */
        }

        .category-scroll::-webkit-scrollbar { display: none; } /* Chrome/Safari */

        .cat-chip {
            background: var(--glass);
            border: 1px solid var(--border);
            color: #aaa;
            padding: 12px 25px;
            border-radius: 50px;
            white-space: nowrap;
            text-decoration: none;
            transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cat-chip:hover, .cat-chip.active-cat {
            background: var(--accent);
            color: #000;
            border-color: var(--accent);
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 10px 20px rgba(255, 193, 7, 0.2);
        }

        .cat-chip i { font-size: 1.2rem; }

        /* --- 3D PRODUCT CARDS --- */
        .product-grid { perspective: 1000px; }

        .product-card {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 25px;
            padding: 15px;
            transition: 0.5s ease;
            transform-style: preserve-3d;
            height: 100%;
        }

        .product-card:hover {
            transform: rotateY(10deg) translateY(-10px);
            border-color: var(--accent);
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
        }

        .product-card img {
            width: 100%;
            height: 220px;
            object-fit: contain;
            border-radius: 20px;
            background: rgba(255,255,255,0.02);
            padding: 10px;
            margin-bottom: 15px;
            transition: 0.5s;
        }

        .product-card:hover img {
            transform: translateZ(50px);
        }

        .price-tag {
            color: var(--accent);
            font-weight: 800;
            font-size: 1.3rem;
        }

        .btn-add {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: white;
            border-radius: 15px;
            padding: 10px;
            transition: 0.3s;
            width: 100%;
            font-weight: 600;
        }

        .btn-add:hover {
            background: var(--accent);
            color: black;
            border-color: var(--accent);
        }

        /* --- LOGOUT ICON --- */
        .btn-logout {
            background: rgba(255, 107, 107, 0.1);
            color: #ff6b6b;
            border: 1px solid rgba(255, 107, 107, 0.2);
            border-radius: 12px;
            padding: 8px 15px;
            transition: 0.3s;
        }

        .btn-logout:hover {
            background: #ff6b6b;
            color: white;
        }

    </style>
</head>
<body>

<nav class="navbar navbar-dark dashboard-nav sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">
            <i class="fa fa-cubes-stacked text-warning me-2"></i>NEXGEN PANEL
        </a>
        <div class="d-flex align-items-center gap-3">
            <a href="../cart/cart.php" class="text-white text-decoration-none position-relative">
                <i class="fa fa-shopping-bag fa-lg"></i>
            </a>
            <a href="logout.php" class="btn-logout text-decoration-none">
                <i class="fa fa-power-off"></i>
            </a>
        </div>
    </div>
</nav>

<div class="container mt-5">

    <div class="welcome-banner">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h2 class="fw-bold mb-1">Hello, <?php echo explode('@', $_SESSION['user'])[0]; ?>! 👋</h2>
                <p class="text-secondary mb-0">The future of technology is ready for you to explore.</p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <a href="../cart/cart.php" class="btn btn-warning px-4 py-2 rounded-pill fw-bold">
                    View Orders
                </a>
            </div>
        </div>
    </div>

    <h5 class="mb-3 fw-bold text-uppercase ls-1" style="font-size: 0.9rem; color: #666;">Filter Experience</h5>
    <div class="category-scroll">
        <a href="user_dashboard.php" class="cat-chip <?php if($category=="") echo "active-cat"; ?>">
            <i class="fa fa-border-all"></i> All Products
        </a>

        <?php
        $cat_query = "SELECT * FROM categories";
        $cat_result = mysqli_query($conn, $cat_query);
        while($c = mysqli_fetch_assoc($cat_result)) {
        ?>
        <a href="?category=<?php echo $c['id']; ?>" 
           class="cat-chip <?php if($category == $c['id']) echo "active-cat"; ?>">
            <i class="fa <?php echo $c['icon']; ?>"></i> <?php echo $c['name']; ?>
        </a>
        <?php } ?>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-4 mt-2">
        <h4 class="fw-bold m-0">Discovery Grid</h4>
        <span class="badge bg-dark border border-secondary px-3 py-2">
            <?php echo ($category == "") ? "Trending Now" : "Category Result"; ?>
        </span>
    </div>

    <div class="row product-grid">
        <?php
        if($category != "") {
            $sql = "SELECT * FROM products WHERE category_id='$category'";
        } else {
            $sql = "SELECT * FROM products ORDER BY id DESC";
        }

        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
            <div class="product-card">
                <img src="../images/<?php echo $row['image']; ?>" alt="Product">
                
                <div class="product-info px-2">
                    <h6 class="fw-bold text-truncate"><?php echo $row['name']; ?></h6>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="price-tag">₹<?php echo number_format($row['price'], 0); ?></span>
                        <a href="../cart/add_cart.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm rounded-circle p-2" style="width:35px; height:35px">
                            <i class="fa fa-plus"></i>
                        </a>
                    </div>
                    <div class="mt-3">
                        <a href="../product.php?id=<?php echo $row['id']; ?>" class="btn btn-add">
                            View Details
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            }
        } else {
            echo "<div class='col-12 text-center py-5'><h5 class='text-secondary'>No products in this sector.</h5></div>";
        }
        ?>
    </div>
</div>

<footer class="py-5 text-center text-secondary mt-5 border-top border-secondary" style="opacity: 0.3;">
    <p>© 2026 NEXGEN | Member Terminal</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>