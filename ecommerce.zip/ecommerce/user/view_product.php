<?php if($view_id != "") { 
    $view_id = mysqli_real_escape_string($conn, $view_id);
    $view_sql = "SELECT * FROM products WHERE id='$view_id'";
    $view_result = mysqli_query($conn, $view_sql);
    $view = mysqli_fetch_assoc($view_result);
?>

<div class="container mt-5 mb-5 view-section">
    <div class="product-view-card">
        <div class="row align-items-center g-0">
            
            <div class="col-lg-5 p-5 text-center stage-left">
                <div class="floating-stage">
                    <img src="../images/<?php echo $view['image']; ?>" class="view-img" alt="Product">
                    <div class="stage-shadow"></div>
                </div>
            </div>

            <div class="col-lg-7 p-5 stage-right">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <span class="badge rounded-pill bg-warning text-dark mb-2 px-3 fw-bold">Verified Product</span>
                        <h1 class="view-title"><?php echo $view['name']; ?></h1>
                    </div>
                    <a href="user_dashboard.php" class="btn-close-view">
                        <i class="fa fa-times"></i>
                    </a>
                </div>

                <div class="view-price">
                    ₹ <?php echo number_format($view['price'], 2); ?>
                </div>

                <div class="view-description">
                    <p>Designed for the next generation. This premium <?php echo $view['name']; ?> combines high-performance engineering with a sleek aesthetic. Built with durable materials and optimized for professional daily use.</p>
                    
                    <ul class="feature-list">
                        <li><i class="fa fa-check-circle text-warning"></i> Next-Gen Performance</li>
                        <li><i class="fa fa-check-circle text-warning"></i> Premium Build Quality</li>
                        <li><i class="fa fa-check-circle text-warning"></i> 24-Month Global Warranty</li>
                    </ul>
                </div>

                <div class="view-actions mt-4 d-flex gap-2">
                    <a href="../cart/add_cart.php?id=<?php echo $view['id']; ?>" class="btn-main btn-glow">
                        <i class="fa fa-cart-plus me-2"></i> Add to Cart
                    </a>
                    <a href="../cart/cart.php" class="btn-main btn-outline">
                        <i class="fa fa-bolt me-2"></i> Instant Buy
                    </a>
                </div>

                <div class="trust-row mt-5 pt-4 border-top border-secondary opacity-50 d-flex gap-4">
                    <div class="small"><i class="fa fa-truck me-1"></i> Fast Shipping</div>
                    <div class="small"><i class="fa fa-lock me-1"></i> Secure Payment</div>
                    <div class="small"><i class="fa fa-undo me-1"></i> 30-Day Return</div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    /* --- VIEW CARD STYLING --- */
    .product-view-card {
        background: rgba(20, 20, 25, 0.8);
        backdrop-filter: blur(25px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 40px;
        overflow: hidden;
        box-shadow: 0 50px 100px rgba(0,0,0,0.7);
        animation: slideUp 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        position: relative;
    }

    /* --- IMAGE STAGE --- */
    .stage-left {
        background: radial-gradient(circle at center, rgba(255,193,7,0.05) 0%, transparent 70%);
        border-right: 1px solid rgba(255,255,255,0.05);
    }

    .floating-stage {
        position: relative;
        perspective: 1000px;
    }

    .view-img {
        width: 100%;
        max-height: 380px;
        object-fit: contain;
        filter: drop-shadow(0 20px 40px rgba(0,0,0,0.5));
        transition: 0.5s ease;
        transform: translateZ(50px);
    }

    .view-img:hover {
        transform: scale(1.1) rotate(2deg);
    }

    .stage-shadow {
        width: 70%;
        height: 20px;
        background: radial-gradient(ellipse at center, rgba(0,0,0,0.5) 0%, transparent 70%);
        margin: -10px auto 0;
        border-radius: 50%;
    }

    /* --- CONTENT STYLING --- */
    .view-title { font-weight: 800; font-size: 2.5rem; letter-spacing: -1px; }
    .view-price { font-size: 2rem; color: #ffc107; font-weight: 700; margin: 15px 0; }
    .view-description p { color: #aaa; font-size: 1.05rem; line-height: 1.7; }
    
    .feature-list { list-style: none; padding: 0; margin: 20px 0; }
    .feature-list li { margin-bottom: 8px; font-size: 0.9rem; color: #eee; }

    /* --- CUSTOM BUTTONS --- */
    .btn-main {
        padding: 15px 35px;
        border-radius: 15px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
        text-decoration: none;
        transition: 0.3s;
        display: inline-block;
    }

    .btn-glow { background: #ffc107; color: #000; box-shadow: 0 10px 20px rgba(255,193,7,0.2); }
    .btn-glow:hover { background: #fff; transform: translateY(-3px); box-shadow: 0 15px 30px rgba(255,193,7,0.4); }
    
    .btn-outline { border: 1px solid rgba(255,255,255,0.2); color: #fff; }
    .btn-outline:hover { background: rgba(255,255,255,0.05); color: #ffc107; border-color: #ffc107; }

    .btn-close-view {
        width: 45px;
        height: 45px;
        background: rgba(255,255,255,0.05);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        text-decoration: none;
        transition: 0.3s;
    }
    .btn-close-view:hover { background: #ff4757; color: #fff; transform: rotate(90deg); }

    /* --- ANIMATIONS --- */
    @keyframes slideUp {
        from { opacity: 0; transform: translateY(40px) scale(0.95); }
        to { opacity: 1; transform: translateY(0) scale(1); }
    }

    @media (max-width: 991px) {
        .stage-left { border-right: none; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .view-title { font-size: 1.8rem; }
    }
</style>

<?php } ?>