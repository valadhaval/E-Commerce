<?php
include "../config/db.php";

if(isset($_POST['register']))
{
    // Added real_escape_string for better security while keeping your core logic
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);

    $sql = "INSERT INTO users(name,email,password) VALUES('$name','$email','$password')";

    if(mysqli_query($conn,$sql)){
        $success = "Identity Verified! Access the portal via login.";
    } else {
        $error = "System Error: Registration trace failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Join the Future</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #0d1117;
            --glass-white: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: radial-gradient(circle at center, #16213e 0%, #0f0f0f 100%);
            font-family: 'Poppins', sans-serif;
            color: white;
            overflow: hidden;
        }

        /* --- 3D FLOATING ANIMATION --- */
        @keyframes float {
            0% { transform: translateY(0px) rotateX(0deg); }
            50% { transform: translateY(-15px) rotateX(2deg); }
            100% { transform: translateY(0px) rotateX(0deg); }
        }

        .register-container {
            width: 440px;
            perspective: 1200px;
            animation: float 6s ease-in-out infinite;
        }

        .register-card {
            background: var(--glass-white);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 35px;
            padding: 50px;
            box-shadow: 0 40px 80px rgba(0,0,0,0.6);
            transform-style: preserve-3d;
            transition: 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .register-card:hover {
            transform: scale(1.02);
            border-color: var(--accent);
        }

        /* --- HEADER ELEMENTS --- */
        .icon-box {
            width: 70px;
            height: 70px;
            background: var(--accent);
            color: #000;
            font-size: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 20px;
            margin: 0 auto 20px;
            transform: translateZ(50px);
            box-shadow: 0 10px 20px rgba(255, 193, 7, 0.3);
        }

        .title {
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-align: center;
            margin-bottom: 30px;
            transform: translateZ(30px);
        }

        /* --- STYLED INPUTS --- */
        .form-group-custom {
            margin-bottom: 18px;
            transform: translateZ(20px);
        }

        .form-control {
            background: rgba(0,0,0,0.2) !important;
            border: 1px solid var(--glass-border) !important;
            border-radius: 12px !important;
            color: #fff !important;
            padding: 12px 18px;
            transition: 0.3s;
        }

        .form-control:focus {
            border-color: var(--accent) !important;
            box-shadow: 0 0 15px rgba(255, 193, 7, 0.15);
            background: rgba(0,0,0,0.4) !important;
        }

        .form-control::placeholder {
            color: rgba(255,255,255,0.4);
            font-size: 14px;
        }

        /* --- BUTTON ACTION --- */
        .register-btn {
            background: var(--accent);
            border: none;
            color: #000;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-radius: 12px;
            padding: 14px;
            margin-top: 10px;
            transition: 0.4s;
            transform: translateZ(40px);
        }

        .register-btn:hover {
            background: #fff;
            transform: translateZ(50px) translateY(-3px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.4);
        }

        /* --- STATUS MESSAGES --- */
        .msg-box {
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 20px;
            font-size: 13px;
            text-align: center;
            border-left: 4px solid;
            transform: translateZ(20px);
        }
        .success { background: rgba(0, 255, 157, 0.1); color: #00ff9d; border-color: #00ff9d; }
        .error { background: rgba(255, 107, 107, 0.1); color: #ff6b6b; border-color: #ff6b6b; }

        .login-link {
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
        }
        .login-link:hover { color: #fff; text-shadow: 0 0 8px var(--accent); }

    </style>
</head>
<body>

<div class="register-container">
    <div class="register-card">

        <div class="icon-box">
            <i class="fa fa-user-plus"></i>
        </div>

        <h3 class="title">Join NexGen</h3>

        <?php if(isset($success)): ?>
            <div class="msg-box success">
                <i class="fa fa-check-circle me-1"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if(isset($error)): ?>
            <div class="msg-box error">
                <i class="fa fa-times-circle me-1"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group-custom">
                <input type="text" name="name" class="form-control" placeholder="Full Identity (Name)" required>
            </div>

            <div class="form-group-custom">
                <input type="email" name="email" class="form-control" placeholder="Email Address" required>
            </div>

            <div class="form-group-custom">
                <input type="password" name="password" class="form-control" placeholder="Secure Password" required>
            </div>

            <div class="d-grid mt-4">
                <button type="submit" name="register" class="btn btn-warning register-btn">
                    Establish Account <i class="fa fa-arrow-right ms-2"></i>
                </button>
            </div>
        </form>

        <div class="text-center mt-4">
            <p class="small text-secondary mb-0">Existing Member?</p>
            <a href="login.php" class="login-link">Access Terminal</a>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>