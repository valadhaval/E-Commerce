<?php include "config/db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Premium 3D Store</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-gold: #ffc107;
            --dark-bg: #0f0f0f;
            --glass-bg: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--dark-bg);
            color: #ffffff;
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
        }

        /* --- MODERN NAVIGATION --- */
        .glass-nav {
            background: rgba(15, 15, 15, 0.8) !important;
            backdrop-filter: blur(15px);
            border-bottom: 1px solid var(--glass-border);
            padding: 15px 0;
        }

        .logo { font-size: 1.5rem; letter-spacing: 2px; color: var(--primary-gold) !important; }

        /* --- HERO SECTION WITH DEPTH --- */
        .hero {
            height: 80vh;
            background: radial-gradient(circle at center, #1a1a1a 0%, #000 100%);
            position: relative;
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .hero::before {
            content: "";
            position: absolute;
            width: 300px;
            height: 300px;
            background: var(--primary-gold);
            filter: blur(150px);
            opacity: 0.15;
            top: 20%;
            left: 10%;
        }

        .hero-title { font-weight: 800; font-size: 4rem; text-transform: uppercase; }
        .hero-text { font-size: 1.2rem; color: #aaa; margin-bottom: 30px; }

        /* --- 3D PRODUCT CARDS --- */
        .product-grid { perspective: 1000px; }

        .product-card {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 20px;
            transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
            transform-style: preserve-3d;
            position: relative;
            height: 100%;
        }

        .product-card:hover {
            transform: translateY(-10px) rotateX(5deg) rotateY(-5deg);
            border-color: var(--primary-gold);
            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
        }

        .product-img {
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            transform: translateZ(50px); /* 3D POP */
        }

        .product-img img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            filter: drop-shadow(0 10px 15px rgba(0,0,0,0.5));
        }

        .product-info {
            margin-top: 20px;
            transform: translateZ(30px);
            text-align: center;
        }

        .price {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--primary-gold);
        }

        /* --- BUTTONS --- */
        .btn-glass {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            color: white;
            transition: 0.3s;
        }

        .btn-glass:hover {
            background: var(--primary-gold);
            color: black;
            transform: scale(1.05);
        }

        /* --- FOOTER --- */
        footer {
            padding: 50px 0;
            background: #050505;
            border-top: 1px solid var(--glass-border);
            margin-top: 100px;
        }

        /* --- ANIMATIONS --- */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .reveal { animation: fadeInUp 0.8s ease forwards; }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark glass-nav fixed-top">
    <div class="container">
        <a class="navbar-brand fw-bold logo" href="#">
            <i class="fa fa-cube me-2"></i>NEXGEN
        </a>
        
        <div class="d-none d-md-block flex-grow-1 mx-5">
            <form action="search.php" class="position-relative">
                <input class="form-control bg-dark border-secondary text-white rounded-pill px-4" 
                       type="search" name="q" placeholder="Search the future...">
                <button class="btn text-warning position-absolute end-0 top-0 mt-1 me-2" type="submit">
                    <i class="fa fa-search"></i>
                </button>
            </form>
        </div>

        <div class="d-flex align-items-center">
            <a href="#" class="text-white me-4 position-relative">
                <i class="fa fa-shopping-cart fa-lg"></i>
            </a>
            <a href="user/login.php" class="btn btn-warning rounded-pill px-4 fw-bold">Login</a>
        </div>
    </div>
</nav>

<section class="hero">
    <div class="container text-center reveal">
        <h1 class="hero-title">Elevate Your <span class="text-warning">Reality</span></h1>
        <p class="hero-text">Experience the next dimension of premium tech accessories.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="#shop" class="btn btn-warning btn-lg px-5 py-3 fw-bold rounded-pill">Shop Now</a>
            <a href="#" class="btn btn-outline-light btn-lg px-5 py-3 rounded-pill">Collections</a>
        </div>
    </div>
</section>

<div class="container mt-5 pt-5" id="shop">
    <div class="d-flex justify-content-between align-items-end mb-5 reveal">
        <div>
            <h6 class="text-warning text-uppercase ls-2">Our Store</h6>
            <h2 class="display-5 fw-bold">Trending Gear</h2>
        </div>
        <a href="#" class="text-warning text-decoration-none">View All <i class="fa fa-arrow-right ms-2"></i></a>
    </div>

    <div class="row product-grid">
        <?php
        $sql = "SELECT * FROM products ORDER BY id DESC";
        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6 mb-5">
            <div class="product-card">
                <div class="product-img">
                    <img src="images/<?php echo $row['image']; ?>" alt="Product">
                </div>
                
                <div class="product-info">
                    <h5 class="fw-bold mb-2"><?php echo $row['name']; ?></h5>
                    <p class="price mb-4">₹<?php echo number_format($row['price'], 2); ?></p>
                    
                    <div class="d-flex gap-2">
                        <a href="#?id=<?php echo $row['id']; ?>" class="btn btn-glass flex-grow-1">
                            Details
                        </a>
                        <a href="#?id=<?php echo $row['id']; ?>" class="btn btn-warning">
                            <i class="fa fa-cart-plus"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            }
        } else {
            echo "<div class='text-center w-100'><p class='text-muted'>No products found.</p></div>";
        }
        ?>
    </div>
</div>

<footer>
    <div class="container text-center">
        <div class="mb-4">
            <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
            <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
            <a href="#" class="text-white"><i class="fab fa-facebook fa-lg"></i></a>
        </div>
        <p class="text-secondary">© 2026 NEXGEN E-Commerce. All Rights Reserved.</p>
        <p class="small text-muted">Designed for the Next Generation of Shoppers.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>