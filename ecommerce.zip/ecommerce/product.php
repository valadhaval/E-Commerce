<?php
include "config/db.php";

// Sanitize the ID to prevent SQL Injection
$id = mysqli_real_escape_string($conn, $_GET['id']);

$sql = "SELECT * FROM products WHERE id='$id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Redirect if product doesn't exist
if (!$row) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $row['name']; ?> | NexGen Premium</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #080808;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: #ffffff;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        /* --- BACKGROUND DECOR --- */
        .bg-glow {
            position: fixed;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(255, 193, 7, 0.1) 0%, transparent 70%);
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: -1;
        }

        /* --- NAVIGATION --- */
        .back-nav {
            position: absolute;
            top: 30px;
            left: 30px;
            z-index: 10;
        }

        .btn-back {
            background: var(--glass);
            border: 1px solid var(--border);
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            text-decoration: none;
            transition: 0.3s;
            backdrop-filter: blur(10px);
        }

        .btn-back:hover {
            background: var(--accent);
            color: #000;
            transform: translateX(-5px);
        }

        /* --- 3D PRODUCT CONTAINER --- */
        .main-card {
            background: var(--glass);
            border: 1px solid var(--border);
            border-radius: 40px;
            padding: 60px;
            backdrop-filter: blur(20px);
            box-shadow: 0 40px 100px rgba(0,0,0,0.8);
            perspective: 1500px;
            margin-top: 80px;
            margin-bottom: 50px;
        }

        /* --- IMAGE STAGE --- */
        .image-stage {
            position: relative;
            transform-style: preserve-3d;
            transition: 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        .image-stage:hover {
            transform: rotateY(15deg) rotateX(5deg);
        }

        .product-img {
            width: 100%;
            max-height: 500px;
            object-fit: contain;
            filter: drop-shadow(0 30px 50px rgba(0,0,0,0.7));
            transform: translateZ(80px); /* Massive depth */
        }

        .img-shadow {
            position: absolute;
            bottom: -20px;
            left: 10%;
            width: 80%;
            height: 40px;
            background: radial-gradient(ellipse at center, rgba(0,0,0,0.6) 0%, transparent 70%);
            transform: rotateX(90deg);
        }

        /* --- CONTENT SECTION --- */
        .content-box {
            padding-left: 40px;
        }

        .badge-new {
            background: var(--accent);
            color: #000;
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: 800;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: inline-block;
            margin-bottom: 15px;
        }

        .product-title {
            font-size: 48px;
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 15px;
        }

        .price-tag {
            font-size: 32px;
            color: var(--accent);
            font-weight: 600;
            margin-bottom: 25px;
        }

        .description {
            color: #aaa;
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 30px;
            border-left: 3px solid var(--accent);
            padding-left: 20px;
        }

        /* --- ACTIONS --- */
        .btn-buy {
            background: var(--accent);
            color: #000;
            font-weight: 800;
            padding: 18px 45px;
            border-radius: 15px;
            border: none;
            transition: 0.4s;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 10px 30px rgba(255, 193, 7, 0.3);
        }

        .btn-buy:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 15px 40px rgba(255, 193, 7, 0.5);
            background: #fff;
        }

        /* --- SPECS LIST --- */
        .specs {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .spec-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: #eee;
        }

        .spec-item i { color: var(--accent); }

        @media (max-width: 992px) {
            .main-card { padding: 30px; margin: 20px; }
            .content-box { padding-left: 0; margin-top: 40px; }
            .product-title { font-size: 32px; }
        }
    </style>
</head>
<body>

<div class="bg-glow"></div>

<div class="back-nav">
    <a href="user/user_dashboard.php" class="btn-back">
        <i class="fa fa-chevron-left me-2"></i> Gallery
    </a>
</div>

<div class="container">
    <div class="main-card">
        <div class="row align-items-center">
            
            <div class="col-lg-6 text-center">
                <div class="image-stage">
                    <img src="images/<?php echo $row['image']; ?>" class="product-img" alt="Product">
                    <div class="img-shadow"></div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="content-box">
                    <span class="badge-new">Exclusive Release</span>
                    <h1 class="product-title"><?php echo $row['name']; ?></h1>
                    
                    <div class="price-tag">
                        ₹ <?php echo number_format($row['price'], 2); ?>
                    </div>

                    <p class="description">
                        Experience engineering excellence with the <?php echo $row['name']; ?>. 
                        Designed for those who demand performance without compromising on aesthetics. 
                        This premium edition features carbon-infused materials and smart-sync technology.
                    </p>

                    <div class="d-grid d-md-block">
                        <a href="cart/add_cart.php?id=<?php echo $row['id']; ?>" class="btn btn-buy">
                            <i class="fa fa-shopping-cart me-2"></i> Add to Cart
                        </a>
                    </div>

                    <div class="specs">
                        <div class="spec-item">
                            <i class="fa fa-shield-alt"></i> 2 Year Warranty
                        </div>
                        <div class="spec-item">
                            <i class="fa fa-truck"></i> Free 24h Delivery
                        </div>
                        <div class="spec-item">
                            <i class="fa fa-undo"></i> 30-Day Returns
                        </div>
                        <div class="spec-item">
                            <i class="fa fa-check-circle"></i> Certified Authentic
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>