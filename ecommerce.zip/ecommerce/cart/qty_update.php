<?php
session_start();

$id=$_GET['id'];
$action=$_GET['action'];

if($action=="plus"){
$_SESSION['cart'][$id]['qty']++;
}

if($action=="minus"){
if($_SESSION['cart'][$id]['qty']>1){
$_SESSION['cart'][$id]['qty']--;
}
}

header("Location:cart.php");
?>