<?php
session_start();
include "../config/db.php";

// Security: Redirect if no order data
if (!isset($_SESSION['order']) || empty($_SESSION['order'])) {
    header("location:../index.php");
    exit();
}

$order = $_SESSION['order'];

// Optional: Update order status to 'Paid' if coming from UPI verification
if (isset($order['payment']) && $order['payment'] === 'UPI' && isset($order['utr'])) {
    // You can update status here if needed
    // Example: mysqli_query($conn, "UPDATE orders SET status='Paid' WHERE transaction_id = '{$order['order_id']}'");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Order Secured</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --accent: #ffc107;
            --success: #00ff9d;
            --bg-dark: #08090a;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }
        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: radial-gradient(circle at center, rgba(0, 255, 157, 0.05), transparent 70%);
        }
        .success-terminal {
            width: 560px;
            background: var(--glass);
            backdrop-filter: blur(30px);
            border: 1px solid var(--border);
            border-radius: 40px;
            padding: 50px 40px;
            text-align: center;
            box-shadow: 0 50px 100px rgba(0,0,0,0.8);
            animation: popIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .check-circle {
            width: 100px;
            height: 100px;
            background: rgba(0, 255, 157, 0.1);
            border: 3px solid var(--success);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            font-size: 42px;
            color: var(--success);
            box-shadow: 0 0 30px rgba(0, 255, 157, 0.3);
        }
        .order-title {
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
        }
        .order-details-box {
            background: rgba(0,0,0,0.3);
            border-radius: 20px;
            padding: 20px;
            margin: 30px 0;
            border: 1px solid var(--border);
            text-align: left;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 14.5px;
        }
        .detail-label {
            color: #888;
            font-size: 11.5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .btn-nexgen {
            padding: 14px 20px;
            border-radius: 15px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
            font-size: 13.5px;
        }
        .btn-invoice {
            background: var(--success);
            color: #000;
        }
        .btn-invoice:hover {
            background: #fff;
            transform: translateY(-3px);
        }
        .btn-dashboard, .btn-shop {
            background: rgba(255,255,255,0.08);
            color: white;
            border: 1px solid var(--border);
        }
        .btn-dashboard:hover, .btn-shop:hover {
            background: rgba(255,255,255,0.15);
            color: var(--accent);
        }
        @keyframes popIn {
            from { opacity: 0; transform: scale(0.85) translateY(30px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }
    </style>
</head>
<body>
<div class="success-terminal">
    <div class="check-circle">
        <i class="fa fa-check"></i>
    </div>
    
    <h2 class="order-title">Order Secured</h2>
    <p class="text-secondary">Thank you, <strong><?php echo htmlspecialchars($order['name']); ?></strong>!</p>

    <div class="order-details-box">
        <div class="detail-row">
            <span class="detail-label">Order ID</span>
            <span class="fw-bold text-warning">#<?php echo htmlspecialchars($order['order_id'] ?? 'NXG-' . time()); ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Total Amount</span>
            <span class="fw-bold text-warning">₹<?php echo number_format($order['total'], 0); ?></span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Payment Method</span>
            <span class="badge bg-dark border border-secondary px-3 py-1">
                <?php echo htmlspecialchars($order['payment']); ?>
            </span>
        </div>
        <?php if (isset($order['utr']) && !empty($order['utr'])): ?>
        <div class="detail-row">
            <span class="detail-label">UTR / Ref No.</span>
            <span class="fw-bold"><?php echo htmlspecialchars($order['utr']); ?></span>
        </div>
        <?php endif; ?>
    </div>

    <div class="d-grid gap-3">
        <!-- Invoice Download -->
        <a href="invoice.php" target="_blank" class="btn-nexgen btn-invoice">
            <i class="fa fa-file-invoice"></i> Download Official Invoice
        </a>

        <!-- View in Dashboard -->
        <a href="../user/user_dashboard.php" class="btn-nexgen btn-dashboard">
            <i class="fa fa-tachometer-alt"></i> Continue Shopping
        </a>

        <!-- Continue Shopping -->
        <a href="../index.php" class="btn-nexgen btn-shop">
            <i class="fa fa-store"></i> View in My Dashboard
        </a>
    </div>

    <p class="mt-4 text-secondary small opacity-75">
        A confirmation email has been sent to <strong><?php echo htmlspecialchars($order['email']); ?></strong>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>