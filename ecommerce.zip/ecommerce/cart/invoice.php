<?php
session_start();

if(!isset($_SESSION['order'])){
    header("location:../index.php");
    exit();
}

$order = $_SESSION['order'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Digital Invoice</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #000;
            --accent: #ffc107;
            --border: #e2e8f0;
        }

        body {
            background-color: #f1f5f9;
            font-family: 'Inter', sans-serif;
            color: #1e293b;
            padding: 40px 0;
        }

        /* --- INVOICE CONTAINER --- */
        .invoice-wrapper {
            max-width: 850px;
            margin: 0 auto;
            background: white;
            padding: 60px;
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }

        /* --- TOP ACCENT BAR --- */
        .invoice-wrapper::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 50px;
        }

        .brand-logo {
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -1px;
            text-transform: uppercase;
        }

        .invoice-label {
            text-align: right;
        }

        .invoice-label h1 {
            font-weight: 900;
            font-size: 45px;
            margin: 0;
            color: #f1f5f9;
            line-height: 1;
        }

        /* --- INFO GRID --- */
        .info-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f8fafc;
        }

        .info-title {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }

        .info-content {
            font-size: 14px;
            line-height: 1.6;
        }

        /* --- TABLE --- */
        .nexgen-table {
            margin-top: 20px;
        }

        .nexgen-table thead th {
            background: #f8fafc;
            border: none;
            color: #475569;
            font-size: 12px;
            text-transform: uppercase;
            padding: 15px;
        }

        .nexgen-table tbody td {
            padding: 20px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }

        /* --- TOTALS --- */
        .total-container {
            margin-top: 30px;
            display: flex;
            justify-content: flex-end;
        }

        .total-card {
            width: 300px;
            background: #1e293b;
            color: white;
            padding: 25px;
            border-radius: 15px;
            text-align: right;
        }

        .grand-total {
            font-size: 24px;
            font-weight: 700;
            color: var(--accent);
        }

        /* --- BUTTONS --- */
        .action-bar {
            max-width: 850px;
            margin: 30px auto;
            text-align: center;
        }

        .btn-print {
            padding: 12px 30px;
            border-radius: 12px;
            font-weight: 700;
            background: var(--primary);
            color: white;
            border: none;
            transition: 0.3s;
        }

        .btn-print:hover {
            background: #334155;
            transform: translateY(-2px);
        }

        /* --- PRINT OPTIMIZATION --- */
        @media print {
            body { background: white; padding: 0; }
            .invoice-wrapper { box-shadow: none; border: none; width: 100%; }
            .action-bar, .print-btn { display: none !important; }
        }
    </style>
</head>
<body>

<div class="invoice-wrapper">
    <div class="header-top">
        <div class="brand-logo">
            <i class="fa fa-cubes text-warning"></i> NexGen <span class="fw-light">Store</span>
        </div>
        <div class="invoice-label">
            <h1>INVOICE</h1>
            <p class="text-secondary small">Ref: #NXG-<?php echo date('Ymd'); ?>-<?php echo rand(10,99); ?></p>
        </div>
    </div>

    <div class="info-section">
        <div>
            <div class="info-title">Billed To</div>
            <div class="info-content">
                <strong class="h5"><?php echo htmlspecialchars($order['name']); ?></strong><br>
                <?php echo htmlspecialchars($order['email']); ?><br>
                <?php echo htmlspecialchars($order['phone']); ?><br>
                <?php echo nl2br(htmlspecialchars($order['address'])); ?>
            </div>
        </div>
        <div class="text-end">
            <div class="info-title">Order Status</div>
            <div class="info-content">
                <strong>Date:</strong> <?php echo date('d M, Y'); ?><br>
                <strong>Payment:</strong> <?php echo htmlspecialchars($order['payment']); ?><br>
                <strong>Method:</strong> Secure Gateway Verified <i class="fa fa-shield-check text-success"></i>
            </div>
        </div>
    </div>

    <table class="table nexgen-table">
        <thead>
            <tr>
                <th>Product Description</th>
                <th class="text-center">Rate</th>
                <th class="text-center">Quantity</th>
                <th class="text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($order['items'] as $item): ?>
            <tr>
                <td class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></td>
                <td class="text-center">₹ <?php echo number_format($item['price'], 2); ?></td>
                <td class="text-center"><?php echo $item['qty']; ?></td>
                <td class="text-end fw-bold">₹ <?php echo number_format($item['price'] * $item['qty'], 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="total-container">
        <div class="total-card">
            <div class="small opacity-50 mb-1 uppercase">Amount Payable</div>
            <div class="grand-total">₹ <?php echo number_format($order['total'], 2); ?></div>
        </div>
    </div>

    <div class="mt-5 pt-4 border-top">
        <div class="row align-items-center">
            <div class="col-6">
                <p class="small text-secondary mb-0">Authorized Signature</p>
                <img src="https://img.icons8.com/ios/100/000000/signature.png" width="80" style="opacity:0.6; filter: grayscale(1);">
            </div>
            <div class="col-6 text-end">
                <p class="small text-secondary">Thank you for choosing NexGen. <br>Innovating your world.</p>
            </div>
        </div>
    </div>
</div>

<div class="action-bar no-print">
    <a href="../user/user_dashboard.php" class="btn btn-outline-secondary me-2 rounded-pill px-4">
        <i class="fa fa-arrow-left"></i> Home
    </a>
    <button onclick="window.print()" class="btn btn-print rounded-pill px-5">
        <i class="fa fa-print"></i> Print / Save as PDF
    </button>
</div>

</body>
</html>