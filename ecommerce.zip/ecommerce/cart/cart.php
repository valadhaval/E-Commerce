<?php
session_start();
// Core logic remains untouched to ensure your backend functionality works perfectly.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Secure Cart</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #0a0c10;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 50% 0%, rgba(255, 193, 7, 0.05) 0%, transparent 50%);
        }

        /* --- HEADER --- */
        .cart-hero {
            padding: 60px 0 30px;
            text-align: center;
        }

        .cart-hero h1 {
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 3px;
        }

        /* --- GLASS CONTAINER --- */
        .cart-wrapper {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 40px;
            padding: 40px;
            box-shadow: 0 40px 100px rgba(0,0,0,0.5);
            margin-bottom: 50px;
        }

        /* --- STYLED TABLE --- */
        .nexgen-table {
            color: white !important;
            border-collapse: separate;
            border-spacing: 0 15px;
        }

        .nexgen-table thead th {
            border: none;
            color: #666;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 1px;
            padding-bottom: 20px;
        }

        .cart-row {
            background: rgba(255,255,255,0.02);
            transition: 0.3s;
        }

        .cart-row:hover {
            background: rgba(255,255,255,0.05);
            transform: scale(1.01);
        }

        .cart-row td {
            padding: 20px !important;
            vertical-align: middle;
            border-top: 1px solid var(--border) !important;
            border-bottom: 1px solid var(--border) !important;
        }

        .cart-row td:first-child { border-left: 1px solid var(--border); border-radius: 20px 0 0 20px; }
        .cart-row td:last-child { border-right: 1px solid var(--border); border-radius: 0 20px 20px 0; }

        /* --- PRODUCT STUFF --- */
        .cart-img {
            width: 80px;
            height: 80px;
            object-fit: contain;
            background: #151515;
            padding: 5px;
            border-radius: 15px;
            border: 1px solid var(--border);
        }

        .qty-control {
            display: flex;
            align-items: center;
            gap: 15px;
            justify-content: center;
            background: #111;
            padding: 5px 15px;
            border-radius: 50px;
            border: 1px solid var(--border);
            width: fit-content;
            margin: 0 auto;
        }

        .qty-link {
            color: var(--accent);
            text-decoration: none;
            font-weight: bold;
            font-size: 18px;
            transition: 0.2s;
        }

        .qty-link:hover { transform: scale(1.4); color: white; }

        /* --- SUMMARY BOX --- */
        .summary-card {
            background: linear-gradient(135deg, #1a1a1a 0%, #000 100%);
            border: 1px solid var(--accent);
            border-radius: 25px;
            padding: 30px;
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 10px 30px rgba(255, 193, 7, 0.1);
        }

        .total-label { color: #aaa; font-size: 14px; text-transform: uppercase; }
        .total-amount { font-size: 2rem; font-weight: 800; color: var(--accent); }

        /* --- ACTION BUTTONS --- */
        .btn-nexgen {
            padding: 15px 35px;
            border-radius: 50px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.4s;
            border: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-back {
            background: rgba(255,255,255,0.05);
            color: white;
            border: 1px solid var(--border);
        }

        .btn-back:hover { background: white; color: black; transform: translateX(-5px); }

        .btn-checkout {
            background: var(--accent);
            color: black;
            box-shadow: 0 10px 20px rgba(255, 193, 7, 0.2);
        }

        .btn-checkout:hover {
            background: #fff;
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(255, 193, 7, 0.4);
        }

        /* --- EMPTY STATE --- */
        .empty-stage {
            padding: 80px 0;
            text-align: center;
            opacity: 0.6;
        }
        .empty-stage i { font-size: 5rem; color: var(--accent); margin-bottom: 20px; }
        /* PREMIUM BUTTON STYLING */
.btn-nexgen.btn-back {
    position: relative;
    display: inline-flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    color: #ffffff;
    padding: 12px 30px;
    border-radius: 15px;
    text-decoration: none;
    font-weight: 600;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
}

.btn-nexgen.btn-back:hover {
    background: #ffffff;
    color: #000000;
    transform: translateX(-8px); /* Moves left to indicate "Going Back" */
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}

.btn-content {
    position: relative;
    z-index: 2;
}

.hover-glow {
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transform: translateX(-100%);
    transition: 0.6s;
}

.btn-nexgen.btn-back:hover .hover-glow {
    transform: translateX(100%);
}

    </style>
</head>
<body>

<section class="cart-hero">
    <div class="container">
        <h1>Your <span style="color:var(--accent)">Vault</span></h1>
        <p class="text-secondary">Review your selected innovations before processing.</p>
    </div>
</section>

<div class="container">
    <div class="cart-wrapper">

        <?php
        $total = 0;
        if(!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
        ?>

        <div class="empty-stage">
            <i class="fa fa-shopping-basket"></i>
            <h3>Your Vault is Empty</h3>
            <p>The future is waiting. Start adding items to your collection.</p>
            <a href="../user/user_dashboard.php" class="btn-nexgen btn-checkout mt-4">
                Explore Store
            </a>
        </div>

        <?php } else { ?>

        <div class="table-responsive">
            <table class="table nexgen-table text-center">
                <thead>
                    <tr>
                        <th>Selection</th>
                        <th>Designation</th>
                        <th>Unit Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                foreach($_SESSION['cart'] as $key => $item) {
                    if(!isset($_SESSION['cart'][$key]['qty'])) {
                        $_SESSION['cart'][$key]['qty'] = 1;
                    }
                    $qty = $_SESSION['cart'][$key]['qty'];
                    $item_total = $item['price'] * $qty;
                    $total += $item_total;
                ?>

                <tr class="cart-row">
                    <td>
                        <img src="../images/<?php echo $item['image']; ?>" class="cart-img">
                    </td>
                    <td class="fw-bold"><?php echo $item['name']; ?></td>
                    <td>₹ <?php echo number_format($item['price'], 2); ?></td>
                    <td>
                        <div class="qty-control">
                            <a href="qty_update.php?action=minus&id=<?php echo $key; ?>" class="qty-link">−</a>
                            <span class="px-2 fw-bold"><?php echo $qty; ?></span>
                            <a href="qty_update.php?action=plus&id=<?php echo $key; ?>" class="qty-link">+</a>
                        </div>
                    </td>
                    <td class="fw-bold text-white">₹ <?php echo number_format($item_total, 2); ?></td>
                    <td>
                        <a href="remove_item.php?id=<?php echo $key; ?>" class="text-danger">
                            <i class="fa fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>

                <?php } ?>

                </tbody>
            </table>
        </div>

        <div class="summary-card">
            <div>
                <span class="total-label">Total Investment</span>
                <div class="total-amount">₹ <?php echo number_format($total, 2); ?></div>
            </div>
            <div class="d-flex gap-3">
                <a href="../user/user_dashboard.php" class="btn-nexgen btn-back">
                 <div class="btn-content">
                 <i class="fa fa-arrow-left me-2"></i>
                 <span>Continue Shopping</span>
            </div>
            <div class="hover-glow"></div>
            </a>
                <a href="checkout.php" class="btn-nexgen btn-checkout">
                    Secure Checkout <i class="fa fa-shield-check"></i>
                </a>
            </div>
        </div>

        <?php } ?>

    </div>
</div>

<footer class="text-center py-5 text-secondary opacity-50">
    <p>© 2026 NEXGEN | Encrypted Transaction Terminal</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>