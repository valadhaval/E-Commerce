<?php
session_start();
// Backend logic remains 100% identical to your provided code.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Secure Cart</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #08090a;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 50% -20%, rgba(255, 193, 7, 0.08), transparent 50%);
        }

        /* --- HEADER SECTION --- */
        .cart-header-area {
            padding: 50px 0 20px;
            text-align: center;
        }

        .cart-header-area h2 {
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 4px;
            margin-bottom: 5px;
        }

        /* --- THE 3D CART TERMINAL --- */
        .terminal-card {
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--border);
            border-radius: 35px;
            padding: 40px;
            box-shadow: 0 40px 80px rgba(0,0,0,0.6);
            margin-top: 20px;
            transform-style: preserve-3d;
        }

        /* --- NATIVE TABLE RE-DESIGN --- */
        .nexgen-table {
            color: white !important;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        .nexgen-table thead th {
            border: none;
            color: #6c757d;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px;
        }

        .cart-item-row {
            background: rgba(255, 255, 255, 0.02);
            transition: 0.3s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        .cart-item-row:hover {
            background: rgba(255, 255, 255, 0.06);
            transform: scale(1.01) translateZ(10px);
        }

        .cart-item-row td {
            padding: 20px !important;
            vertical-align: middle;
            border-top: 1px solid var(--border) !important;
            border-bottom: 1px solid var(--border) !important;
        }

        .cart-item-row td:first-child { border-left: 1px solid var(--border); border-radius: 20px 0 0 20px; }
        .cart-item-row td:last-child { border-right: 1px solid var(--border); border-radius: 0 20px 20px 0; }

        /* --- QUANTITY CONTROLS --- */
        .qty-terminal {
            display: inline-flex;
            align-items: center;
            background: #000;
            border: 1px solid var(--border);
            border-radius: 50px;
            padding: 5px 15px;
            gap: 15px;
        }

        .qty-link {
            color: var(--accent);
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .qty-link:hover { transform: scale(1.3); color: #fff; }

        /* --- TOTAL FOOTER --- */
        .total-summary {
            background: linear-gradient(90deg, transparent, rgba(255, 193, 7, 0.05));
            border-radius: 20px;
            padding: 25px;
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid var(--border);
        }

        .total-label { font-size: 14px; color: #aaa; text-transform: uppercase; }
        .total-value { font-size: 28px; font-weight: 800; color: var(--accent); }

        /* --- ACTION BUTTONS --- */
        .btn-nexgen {
            padding: 14px 35px;
            border-radius: 15px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: 0.4s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .btn-back {
            background: rgba(255,255,255,0.05);
            color: #fff;
            border: 1px solid var(--border);
        }

        .btn-back:hover { 
            background: #fff; 
            color: #000; 
            transform: translateX(-5px); 
        }

        .btn-checkout {
            background: var(--accent);
            color: #000;
            box-shadow: 0 10px 30px rgba(255, 193, 7, 0.3);
        }

        .btn-checkout:hover {
            background: #fff;
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(255, 193, 7, 0.5);
        }

        /* --- EMPTY STATE --- */
        .empty-vault {
            padding: 60px 0;
            text-align: center;
        }
        .empty-vault i { font-size: 4rem; color: var(--accent); opacity: 0.5; margin-bottom: 20px; }

    </style>
</head>
<body>

<div class="cart-header-area">
    <div class="container">
        <h2>Order <span style="color:var(--accent)">Vault</span></h2>
        <p class="text-secondary small">SECURE TRANSACTION TERMINAL // SESSION ACTIVE</p>
    </div>
</div>

<div class="container">
    <div class="terminal-card">

        <?php
        $total = 0;
        if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        ?>

        <div class="table-responsive">
            <table class="table nexgen-table">
                <thead>
                    <tr>
                        <th>Product Info</th>
                        <th>Unit Price</th>
                        <th class="text-center">Quantity</th>
                        <th>Subtotal</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                foreach($_SESSION['cart'] as $key => $item) {
                    if(!isset($_SESSION['cart'][$key]['qty'])){
                        $_SESSION['cart'][$key]['qty'] = 1;
                    }
                    $qty = $_SESSION['cart'][$key]['qty'];
                    $item_total = $item['price'] * $qty;
                    $total += $item_total;
                ?>

                <tr class="cart-item-row">
                    <td class="fw-bold">
                        <i class="fa fa-microchip text-warning me-2"></i>
                        <?php echo $item['name']; ?>
                    </td>
                    <td>₹ <?php echo number_format($item['price'], 2); ?></td>
                    <td class="text-center">
                        <div class="qty-terminal">
                            <a href="qty_update.php?action=minus&id=<?php echo $key; ?>" class="qty-link">
                                <i class="fa fa-minus small"></i>
                            </a>
                            <span class="fw-bold"><?php echo $qty; ?></span>
                            <a href="qty_update.php?action=plus&id=<?php echo $key; ?>" class="qty-link">
                                <i class="fa fa-plus small"></i>
                            </a>
                        </div>
                    </td>
                    <td class="fw-bold text-white">₹ <?php echo number_format($item_total, 2); ?></td>
                    <td class="text-center">
                        <a href="remove_item.php?id=<?php echo $key; ?>" class="text-danger opacity-75 h5">
                            <i class="fa fa-trash-alt"></i>
                        </a>
                    </td>
                </tr>

                <?php } ?>

                </tbody>
            </table>
        </div>

        <div class="total-summary">
            <div>
                <div class="total-label">Final Investment</div>
                <div class="total-value">₹ <?php echo number_format($total, 2); ?></div>
            </div>
            <div class="d-flex gap-3">
                <a href="../user/user_dashboard.php" class="btn-nexgen btn-back">
                    <i class="fa fa-arrow-left"></i> Shopping
                </a>
                <a href="checkout.php" class="btn-nexgen btn-checkout">
                    Checkout <i class="fa fa-shield-check"></i>
                </a>
            </div>
        </div>

        <?php } else { ?>

        <div class="empty-vault">
            <i class="fa fa-box-open d-block"></i>
            <h4 class="fw-bold">Vault is Empty</h4>
            <p class="text-secondary">Your high-performance selection will appear here.</p>
            <a href="../index.php" class="btn-nexgen btn-checkout mt-3">
                <i class="fa fa-shopping-bag"></i> Discover Products
            </a>
        </div>

        <?php } ?>

    </div>
</div>

<footer class="text-center py-5 opacity-25 small">
    <p>© 2026 NEXGEN SECURITY // ENCRYPTED CART</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>