<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    header("location:cart.php");
    exit();
}

// 1. Capture Data
$name          = mysqli_real_escape_string($conn, $_POST['name']);
$email         = mysqli_real_escape_string($conn, $_POST['email']);
$phone         = mysqli_real_escape_string($conn, $_POST['phone']);
$address       = mysqli_real_escape_string($conn, $_POST['address']);
$payment_method = mysqli_real_escape_string($conn, $_POST['payment']);

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['qty'];
}

// ================== YOUR REAL UPI DETAILS ==================
$my_upi_id     = "valadhaval1619@oksbi";     // ← CHANGE TO YOUR REAL REGISTERED UPI ID
$merchant_name = "NexGen Store";
$transaction_id = "NXG" . time();

// UPI Deep Link
$upi_url = "upi://pay?pa=$my_upi_id&pn=" . urlencode($merchant_name) . 
           "&tr=$transaction_id&am=$total&cu=INR&tn=" . urlencode("Order #$transaction_id for $name");

// ================== HANDLE COD ==================
if ($payment_method === 'COD') {
    foreach ($_SESSION['cart'] as $item) {
        $p_name  = mysqli_real_escape_string($conn, $item['name']);
        $p_price = $item['price'];
        $qty     = $item['qty'];

        $sql = "INSERT INTO orders 
                (user_email, total, payment_method, order_date, product_name, product_price, qty)
                VALUES ('$email', '$total', 'Cash On Delivery', NOW(), '$p_name', '$p_price', '$qty')";
        mysqli_query($conn, $sql);
    }

    // Store order for success page
    $_SESSION['order'] = [
    "name"       => $name,
    "email"      => $email,
    "phone"      => $phone,
    "address"    => $address,
    "payment"    => $payment_method,   // COD or UPI
    "total"      => $total,
    "items"      => $_SESSION['cart'],
    "order_id"   => $transaction_id,
    "utr"        => $utr ?? ''         // only for UPI
];
    unset($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NexGen | Secure Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { 
            background: #08090a; 
            color: white; 
            font-family: 'Poppins', sans-serif; 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center;
        }
        .payment-card { 
            background: rgba(255, 255, 255, 0.03); 
            border: 1px solid rgba(255, 255, 255, 0.1); 
            border-radius: 30px; 
            padding: 40px; 
            max-width: 500px; 
            width: 100%; 
            backdrop-filter: blur(20px); 
            text-align: center; 
        }
        .qr-box { 
            background: white; 
            padding: 15px; 
            border-radius: 20px; 
            display: inline-block; 
            margin: 20px 0; 
        }
        .upi-apps { 
            display: flex; 
            justify-content: center; 
            gap: 15px; 
            margin-top: 20px; 
        }
        .upi-apps img { 
            width: 45px; 
            height: 45px; 
            border-radius: 10px; 
            object-fit: contain;
        }
        .btn-verify { 
            background: #ffc107; 
            color: #000; 
            font-weight: 700; 
            border-radius: 12px; 
            padding: 14px; 
            margin-top: 20px; 
        }
        .form-control { 
            background: rgba(255,255,255,0.05); 
            border: 1px solid rgba(255,255,255,0.1); 
            color: white; 
            text-align: center; 
        }
    </style>
</head>
<body>
<div class="payment-card">
    <?php if ($payment_method !== 'COD'): ?>
        <h4 class="text-warning mb-2">Complete UPI Payment</h4>
        <p class="small text-secondary">Pay <b>₹<?php echo number_format($total, 2); ?></b> to confirm your order</p>
        
        <div class="qr-box">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=<?php echo urlencode($upi_url); ?>" 
                 alt="UPI QR Code">
        </div>

        <p class="small text-warning mb-3">
            <i class="fa fa-info-circle"></i> Scan with any UPI app or click below
        </p>

        <div class="upi-apps">
            <a href="<?php echo $upi_url; ?>" target="_blank"><img src="https://upload.wikimedia.org/wikipedia/commons/c/c4/Google_Pay_Logo.svg" alt="GPay"></a>
            <a href="<?php echo $upi_url; ?>" target="_blank"><img src="https://download.logo.wine/logo/PhonePe/PhonePe-Logo.wine.png" alt="PhonePe"></a>
            <a href="<?php echo $upi_url; ?>" target="_blank"><img src="https://download.logo.wine/logo/Paytm/Paytm-Logo.wine.png" alt="Paytm"></a>
        </div>

        <hr class="my-4 opacity-25">

        <form action="verify_payment.php" method="POST">
            <label class="small mb-2 d-block text-start">Enter UTR / Transaction ID after payment</label>
            <input type="text" name="utr" class="form-control mb-3" placeholder="Example: 123456789012" maxlength="12" required>
            
            <input type="hidden" name="email" value="<?php echo $email; ?>">
            <input type="hidden" name="total" value="<?php echo $total; ?>">
            <input type="hidden" name="transaction_id" value="<?php echo $transaction_id; ?>">
            <input type="hidden" name="name" value="<?php echo $name; ?>">
            <input type="hidden" name="phone" value="<?php echo $phone; ?>">
            <input type="hidden" name="address" value="<?php echo $address; ?>">

            <button type="submit" class="btn btn-verify w-100">
                <i class="fa fa-check-circle"></i> I Have Paid - Confirm Order
            </button>
        </form>

    <?php else: ?>
        <i class="fa fa-circle-check text-success fa-5x mb-4"></i>
        <h3>Order Placed Successfully!</h3>
        <p class="text-secondary">Redirecting to receipt...</p>
        <script>
            setTimeout(() => { 
                window.location.href = "order_success.php"; 
            }, 2000);
        </script>
    <?php endif; ?>
</div>
</body>
</html>