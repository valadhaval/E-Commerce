<?php
session_start();

if(!isset($_SESSION['cart']) || count($_SESSION['cart'])==0){
    header("location:cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexGen | Secure Checkout</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --accent: #ffc107;
            --bg-dark: #08090a;
            --glass: rgba(255, 255, 255, 0.03);
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-dark);
            color: white;
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background-image: radial-gradient(circle at 80% 20%, rgba(255, 193, 7, 0.05), transparent 40%);
        }

        .checkout-hero {
            padding: 40px 0;
            text-align: center;
            border-bottom: 1px solid var(--border);
            background: rgba(0,0,0,0.3);
        }

        .checkout-card {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 35px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.4);
            transition: 0.4s;
        }

        h4 { color: var(--accent); font-weight: 700; margin-bottom: 25px; }

        .form-control {
            background: rgba(255,255,255,0.05) !important;
            border: 1px solid var(--border) !important;
            border-radius: 12px !important;
            color: white !important;
            padding: 12px 18px;
        }

        .form-control:focus { border-color: var(--accent) !important; box-shadow: 0 0 15px rgba(255, 193, 7, 0.2); }

        /* Payment Dynamic Section */
        #payment-details {
            background: rgba(0,0,0,0.2);
            border-radius: 15px;
            padding: 0;
            margin-top: 0;
            transition: 0.5s ease;
            overflow: hidden;
            max-height: 0;
        }

        #payment-details.active {
            padding: 20px;
            margin-top: 15px;
            border: 1px solid var(--border);
            max-height: 500px;
        }

        .summary-table { color: white !important; }
        .summary-table th { color: #666; font-size: 11px; text-transform: uppercase; border: none; }

        .total-box {
            background: #000;
            border: 1px dashed var(--accent);
            padding: 20px;
            border-radius: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }

        .order-btn {
            background: var(--accent);
            color: #000;
            font-weight: 800;
            text-transform: uppercase;
            padding: 16px;
            border-radius: 15px;
            border: none;
            margin-top: 25px;
            transition: 0.4s;
        }

        .order-btn:hover { background: #fff; transform: translateY(-5px); box-shadow: 0 15px 30px rgba(255, 193, 7, 0.3); }
    </style>
</head>
<body>

<div class="checkout-hero">
    <div class="container">
        <h2>Secure <span style="color:var(--accent)">Checkout</span></h2>
        <a href="cart.php" class="text-secondary text-decoration-none small"><i class="fa fa-arrow-left"></i> Return to Cart</a>
    </div>
</div>

<div class="container mt-5 mb-5">
    <form action="place_order.php" method="post" id="checkoutForm">
        <div class="row g-4">

            <div class="col-lg-7">
                <div class="checkout-card">
                    <h4><i class="fa fa-map-location-dot"></i> Shipping Details</h4>
                    
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="small text-secondary mb-2">Full Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="small text-secondary mb-2">Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="small text-secondary mb-2">Phone</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="small text-secondary mb-2">Address</label>
                            <textarea name="address" class="form-control" rows="2" required></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <label class="small text-secondary mb-2">Payment Method</label>
                            <select name="payment" id="payMethod" class="form-control" onchange="updatePaymentUI()">
                                <option value="COD">Cash On Delivery</option>
                                <option value="UPI">UPI Transfer</option>
                                <option value="CARD">Credit / Debit Card</option>
                            </select>
                        </div>

                        <div class="col-md-12">
                            <div id="payment-details">
                                </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="checkout-card">
                    <h4><i class="fa fa-receipt"></i> Order Summary</h4>
                    <div class="table-responsive">
                        <table class="table summary-table">
                            <thead>
                                <tr><th>Item</th><th class="text-center">Qty</th><th class="text-end">Subtotal</th></tr>
                            </thead>
                            <tbody>
                                <?php
                                $total=0;
                                foreach($_SESSION['cart'] as $item){
                                    $item_total = $item['price'] * $item['qty'];
                                    $total += $item_total;
                                ?>
                                <tr>
                                    <td class="small fw-bold"><?php echo $item['name']; ?></td>
                                    <td class="text-center small"><?php echo $item['qty']; ?></td>
                                    <td class="text-end fw-bold">₹<?php echo number_format($item_total, 0); ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="total-box">
                        <span class="text-secondary small">Total Payable</span>
                        <span class="fs-4 fw-bold text-warning">₹<?php echo number_format($total, 0); ?></span>
                    </div>

                    <button type="submit" class="order-btn w-100">
                        Process Final Order <i class="fa fa-shield-check ms-2"></i>
                    </button>
                    
                    <div class="text-center mt-4">
                        <p class="text-secondary" style="font-size: 10px;">
                            <i class="fa fa-lock me-1"></i> END-TO-END ENCRYPTED GATEWAY
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </form>
</div>

<script>
    function updatePaymentUI() {
        const method = document.getElementById('payMethod').value;
        const container = document.getElementById('payment-details');
        
        if (method === 'COD') {
            container.classList.remove('active');
            container.innerHTML = "";
        } else {
            container.classList.add('active');
            if (method === 'UPI') {
                container.innerHTML = `
                    <label class="small text-warning">Enter UPI ID</label>
                    <input type="text" class="form-control mb-2" placeholder="username@upi">
                    <p class="text-muted" style="font-size:10px">Open your UPI app to approve the request after clicking place order.</p>
                `;
            } else if (method === 'CARD') {
                container.innerHTML = `
                    <label class="small text-warning">Card Number</label>
                    <input type="text" class="form-control mb-2" placeholder="XXXX XXXX XXXX XXXX">
                    <div class="row">
                        <div class="col-6">
                            <label class="small text-warning">Expiry</label>
                            <input type="text" class="form-control" placeholder="MM/YY">
                        </div>
                        <div class="col-6">
                            <label class="small text-warning">CVV</label>
                            <input type="password" class="form-control" placeholder="***">
                        </div>
                    </div>
                `;
            }
        }
    }
</script>

</body>
</html>