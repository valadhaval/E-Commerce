<?php

session_start();

include "../config/db.php";

$id=$_GET['id'];

$sql="SELECT * FROM products WHERE id=$id";

$result=mysqli_query($conn,$sql);

$product=mysqli_fetch_assoc($result);

$_SESSION['cart'][]=$product;

header("Location:view_cart.php");

?>