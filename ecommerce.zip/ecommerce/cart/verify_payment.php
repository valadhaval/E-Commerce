<?php
session_start();
include "../config/db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['cart'])) {
    // Capture and clean data
    $utr            = mysqli_real_escape_string($conn, $_POST['utr']);
    $email          = mysqli_real_escape_string($conn, $_POST['email']);
    $total          = mysqli_real_escape_string($conn, $_POST['total']);
    $transaction_id = mysqli_real_escape_string($conn, $_POST['transaction_id']);
    $name           = mysqli_real_escape_string($conn, $_POST['name']);
    $phone          = mysqli_real_escape_string($conn, $_POST['phone']);
    $address        = mysqli_real_escape_string($conn, $_POST['address']);

    // 1. Insert each item into the database
    foreach ($_SESSION['cart'] as $item) {
        $p_name  = mysqli_real_escape_string($conn, $item['name']);
        $p_price = $item['price'];
        $qty     = $item['qty'];
        
        $sql = "INSERT INTO orders 
                (user_email, total, payment_method, order_date, product_name, product_price, qty) 
                VALUES ('$email', '$total', 'UPI (UTR: $utr)', NOW(), '$p_name', '$p_price', '$qty')";
        mysqli_query($conn, $sql);
    }

    // 2. Store details in session for the Invoice
    $_SESSION['order_summary'] = [
        "order_id" => $transaction_id,
        "name"     => $name,
        "email"    => $email,
        "phone"    => $phone,
        "address"  => $address,
        "total"    => $total,
        "utr"      => $utr,
        "items"    => $_SESSION['cart'], // Save items before unsetting cart
        "date"     => date('d M Y, h:i A')
    ];

    // 3. Clear the cart
    unset($_SESSION['cart']);

    // 4. Redirect to success page
    header("location:order_success.php");
    exit();
} else {
    header("location:cart.php");
    exit();
}
?>