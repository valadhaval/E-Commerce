<?php

$host = "sql100.infinityfree.com"; // ⚠ panel se exact copy karo
$user = "if0_41482376";
$pass = "5nKGEvVWoKhRud";
$db   = "if0_41482376_ecommerce"; // ya jo actual DB hai

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Database Connection Failed: " . mysqli_connect_error());
}else{
    echo "Database Connected Successfully";
}

?>